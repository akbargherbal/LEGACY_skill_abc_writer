# session-15 — the whole-draft pilot (v1 preview)

Same lyrics, style and model as session 14. The process change: the composer
writes the whole score in one draft (or three large sections), then validates
with `scorecard.py`; `line`/`patch`/per-line meters are not the workflow.

- Skill: **1.0.0** (`SKILL.md` is the short whole-draft contract).
- Composer: `steps: 24`, **may write `score.abc` directly**.
- Validator: `scorecard.py` (KEY BANDS / BLOCKING / POLISH / SEAMS).
- No `composition.json`, no Python composer, no renderer.

```bash
unzip session-15-v1-preview.zip
cd session-15
opencode --auto
# paste PROMPT.txt (outside this directory)
```

Start clean: no `plan.json`, `phrases.json` or `score.abc` before the composer.
It must run `init` itself.

After the run, run:

```bash
python3 skills/abc-score-writer/scripts/scorecard.py score.abc \
  --plan plan.json --phrases phrases.json
```
