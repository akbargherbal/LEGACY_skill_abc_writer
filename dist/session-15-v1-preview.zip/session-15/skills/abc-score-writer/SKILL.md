---
name: abc-score-writer
version: "1.0.0"
description: >-
  Write a complete two-voice ABC score from Arabic lyrics and an arabmaqamrock
  style prompt in whole drafts, then validate it with one scorecard. The model
  composes; the tools validate. Use when asked to write, compose, generate or
  design a score, melody, or ABC file from lyrics and a style. Do NOT use for
  editing an existing SheetSage2 transcription.
---

# abc-score-writer

You are the composer. The tune is the work. The tools measure and reject; they
never choose a note.

**Write the whole score. Then fix it whole. Do not patch bar by bar.**

## The loop

```text
init -> draft (whole) -> scorecard -> rewrite (whole) -> scorecard
     -> polish seams -> release
```

At most **4 drafts**. If the same blocking issue survives two full rewrites,
stop and report: the model or the plan is the limit, not the card.

## 1. Init

```bash
python3 <skill>/scripts/score_cli.py init --tempo 80
```

Read `plan.json` and `phrases.json`. Use `--sections` when the form is decided.
If `FORM BUDGET` appears, decide before the first draft: keep the compact form
and accept the warning, or rerun with `--force --bars N` **and** `--sections`.

## 2. Draft the whole score

Write `score.abc` in **one pass**, or at most **three large sections**
(intro+verse 1, chorus+verse 2, chorus 2+outro). A 2-4k-token score is one
draft; it fits the call cap.

- No `line`, no `patch`, no per-bar meter.
- No Python parser, no hand sums. The scorecard is the measurement.
- Keep the cell, period, cadence ladder, register arc and texture in your head
  or in a short note. Do not write a DSL or a composition compiler.

If the draft is long, split by **section**, not by lyric line.

## 3. Scorecard

```bash
python3 <skill>/scripts/scorecard.py score.abc --plan plan.json --phrases phrases.json
```

The card has four parts:

- `KEY BANDS` — the checker's numbers and their verdicts (`FAIL` hard, `WARN`
  plan/polish).
- `BLOCKING` — hard failures. Fix all of them in the next draft.
- `POLISH` — warnings and taste risks. Fix what the ear hears.
- `SEAMS` — line-to-line joints: cadence -> start, rest, register, overlap.

Exit code `1` means blocking; `2` means a parse error. Read the card, not the
exit code alone.

## 4. Rewrite the whole score

Use the card. Fix **blocking first**. Rewrite the **whole file** (or a whole
section), not one bar. A 3k rewrite is cheaper and safer than 45 patches.
Repeat 1-4 times.

- `simultaneity` — the cap is **4 units total**, not per bar. Pull `Ins` out of
  the vocal, or declare a `simultaneity_exception` bar.
- `repeated notes` — repeat pitches at phrase heads and cadences; the floor is
  **20%**.
- `register mean` — the hard band is **69-79**; the plan target is separate.
- `parse error` — fix the bar sums first; no other number is meaningful.

## 5. Polish seams, release

When `BLOCKING` is empty, polish the flagged seams: section transitions,
same-pitch joints, register jumps, short rests, guitar under the voice. Then:

```bash
python3 <skill>/scripts/score_cli.py release
```

The ear is the judge. The card is the guard. If there is no audio, do not claim
a musical verdict.

## Rules

- **The model writes notes. The tools never compose.**
- No hand-written parsers or metric scripts; the scorecard is the measurement.
- No micro-edits; no 26-line loop; no patch-by-patch repair.
- Do not lower the checker or `calibration.json`; do not add taste gates.
- Stop when the card has no blocking and the ear is satisfied. Do not keep
  editing after a pass.
- If the same blocking issue survives two full rewrites, stop and report.

## ABC contract (short)

- Header: use the scaffold header that `init` writes (`X:1`, `T:`, `M:4/4`,
  `L:1/16`, `Q:1/4=<tempo>`, the two `V:` lines, `K:<key>`). Do not invent it.
- Each `V:` block is followed by up to 4 bars; every bar sums to **16 units**;
  `Z` is a whole-bar rest.
- The last bar is `Z` in both voices.
- Durations: `1,2,3,4,6,8,12,16,24,32,48`. Ties are `A4-A2`; no dots, no
  tuplets, no `[...]`.
- Read `example/score.abc` before the first draft; it is the dialect reference.

## Legacy

`line`, `patch`, `core` and the live meter still exist in `score_cli.py` for
emergency repair and for the 0.9 archive. They are **not** this workflow. Do
not use them to compose a new score.
