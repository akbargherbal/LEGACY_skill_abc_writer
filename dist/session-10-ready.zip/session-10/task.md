# Session 10 — quality run (abc-score-writer 0.7.0)

Load the `abc-score-writer` skill with the `skill` tool **first**. If it fails,
stop immediately and write `HARNESS_FAIL.md`; do not read `SKILL.md` manually.

Work in this directory. Read `input/lyrics.txt` and `input/style.md`. Do not
modify `skills/`.

## Inputs

- D Kurd: `K:Dm`, `_E` for the b2, 80 BPM, 4/4.
- Section layout for the syllabifier:
  `intro=7,verse 1=13,chorus=37,verse 2=46,chorus=65,outro=77`.
- Offline: no renderer; do not claim an audition.
- Do not retrieve an exemplar or a phrase bank.
- Do not create a task list.

## Session choices

- **Register:** use `skills/abc-score-writer/example/plan.json`; do not
  override it (mean 70).
- **Quality run:** `quality_targets.json` is part of acceptance. Run
  `quality.py`; all five objective targets must pass. Taste is the critic's,
  not a gate.
- **Qafla:** every section end and the final line holds a quarter or longer;
  the final note is at least half a bar, with a 3–5 note turn.
- **Rhythm:** break the eighth grid. Vary the per-line rhythm cell; hit
  `craft.md`'s targets and the pause hierarchy. No line may run past
  `max_unbroken_seconds`.
- **Chorus:** a new opening motif, not a sequence of the verse head; keep a
  distinct tail.
- **Bed:** if a guitar bed is needed, put it in `seed.abc` only; `score.abc`
  stays two voices.
- **Economy:** generated (`output + reasoning`) ≤ 10× (score + seed); the
  analyst stops at that line. Do not spend tokens on a parser or a stats
  script.

## Pipeline — one order

1. **State.** Copy `skills/abc-score-writer/templates/state.json` and
   `templates/STATE.md` to this directory. Update both after each step.
2. **Syllabify once.**
   ```bash
   python3 skills/abc-score-writer/scripts/syllabify.py input/lyrics.txt \
     --tempo 80 --json prosody.json --phrases phrases.json \
     --sections "intro=7,verse 1=13,chorus=37,verse 2=46,chorus=65,outro=77"
   ```
   Use the emitted absolute `bar_start`/`bar_end`; do not retype the table.
   The sidecar's `pause_after_s` is the intended rest: set it to the hierarchy
   (caesura 0.5–0.75 s, line end 1.0–1.5 s, section end longer). Do not change
   the bar ranges.
3. **Core first.** Write `core_draft.abc`, 8–16 bars. It is the first
   composition file. **Do not write `plan.json` or `score.abc` before it.**
   Do not design the full 82 bars first. Use the targets in
   `example/plan.json` and the bars in `prosody.json`/`phrases.json`.
4. **Review the core.** Run:
   ```bash
   python3 skills/abc-score-writer/scripts/craft.py core_draft.abc \
     --phrases phrases.json --json core_table.json
   ```
   Then read `skills/abc-score-writer/references/critic.md` and write
   `core_review.md` as exactly **5 numbered lines**, each tied to a bar.
   Fix the core before expanding.
5. **Plan.** Write `plan.json` after the core review. Use the complete plan
   schema; `strict_shape: false`; register 70; maqam Kurd.
6. **Score once.** Write `score.abc` (Vocal + Ins), expanding the core to 82
   bars. The core must remain the first bars. Do not rewrite the whole score
   later; use `edit` for named bars.
7. **Checker.**
   ```bash
   python3 skills/abc-score-writer/scripts/checker.py score.abc \
     --plan plan.json --phrases phrases.json --json report.json \
     --require-final-rest
   ```
   On FAIL, run `repair.py` and edit only the named bars. Maximum 4 checker
   runs; stop after a pass; no checker run after a pass.
8. **Quality.**
   ```bash
   python3 skills/abc-score-writer/scripts/quality.py score.abc \
     --plan plan.json --phrases phrases.json \
     --targets quality_targets.json --json quality.json
   ```
   If it fails, use `repair.json`/`repair.py` for one scoped fix and one
   verification. A quality run is not done while an objective target is open.
9. **Seed and docs.** Write `seed.abc` (Vocal/Ins + chords + `V: Drums`; add
   bass/guitar/orchestra only in the seed), then `seed_sheet.md` and `notes.md`
   as exactly 10 numbered lines each, after `score.abc`.
10. **Package check.**
    ```bash
    python3 skills/abc-score-writer/scripts/verify_package.py \
      --score score.abc --seed seed.abc --plan plan.json \
      --core core_draft.abc --sheet seed_sheet.md --notes notes.md \
      --review core_review.md --report report.json --state state.json \
      --json verify.json
    python3 skills/abc-score-writer/scripts/craft.py score.abc \
      --phrases phrases.json --json craft.json
    ```
    Update `state.json`/`STATE.md` after every check.

## Artifacts

`core_draft.abc`, `core_review.md`, `prosody.json`, `phrases.json`,
`plan.json`, `score.abc`, `seed.abc`, `seed_sheet.md`, `notes.md`,
`report.json`, `repair.json` (if a global failure), `quality.json`,
`craft.json`, `core_table.json` (both include the per-line table when
`--phrases` is used), `verify.json`, `state.json`, `STATE.md`, `CHANGES.txt`.

## Stop rules

- First `skill` call fails, or the cwd is dirty → write `HARNESS_FAIL.md` and
  stop.
- No `core_draft.abc` first, or `plan.json`/`score.abc` before it → stop.
- A second full write of `score.abc` → stop.
- A checker run after a pass → stop.
- A quality target left open → not done.
- **0 custom parser/stats scripts.** Use the bundled tools. If a number is
  missing, record it in `notes.md` and use the closest tool; do not write a
  heredoc.
- Do not edit `checker.py`, `calibration.json`, `abc_tools.py`, or the skill.
- Do not ask questions. Finish the package and write `CHANGES.txt`.
