# Session 10 package — certification

**Built:** 2026-11-25
**Skill:** `abc-score-writer` 0.7.0
**Skill zip SHA-256:** `65a953fa5cb5e684b2478b953591c1a29ba7c08c531a175b782ebe94df8e3c1a`
**`SKILL.md` SHA-256:** `ebc040eafd3cfd26ffe3042d7a364c3c045c66357117a17f3f3e9f12fc545fdd`
**Model in `opencode.json`:** `deepseek/deepseek-flash#high`
**Session folder:** `session-10/`

## Start

```bash
cd session-10
opencode --auto
```

Then paste the prompt in `PROMPT.txt`:

```text
Read task.md and follow it exactly.
Load the abc-score-writer skill with the skill tool first.
If it fails, stop immediately and write HARNESS_FAIL.md.
Do not read SKILL.md manually.
Work autonomously; do not ask questions. Finish all artifacts.
```

`opencode.json` registers the skill from `./skills` and fixes the paid model from
the first token. No global symlink, no `@path`, no `/skill`, no late model
addition.

## W0 — skill loading

The packaged project was smoke-tested in this folder:

```bash
opencode run --model deepseek/deepseek-flash#high --agent build --auto \
  "Load the abc-score-writer skill with the skill tool.
   If it loads, print exactly SKILL_OK and stop.
   If it fails, print exactly SKILL_FAIL and stop."
```

Result: **`SKILL_OK`**. The first `skill` call succeeded, unlike sessions
07/08/09. `opencode.json` has `skills: ["./skills"]` and the skill ID resolves
to `abc-score-writer` from `skills/abc-score-writer/SKILL.md`.

## W5 — tool validation (archived scores, no composition)

### Selftest and unit tests

- Packaged `skills/abc-score-writer/scripts/selftest.sh`: **PASS**.
- `python3 -m unittest discover -s tests`: **73 tests OK**.

### `craft.py --phrases`

| Case | lyric lines | detected phrases | merged |
|---|---:|---:|---:|
| 09 final | 26 | 26 | 0 |
| 08 | 26 | 26 | 0 |
| synthetic grid (continuous notes) | 4 | **1** | **3** |

The grid case is the 09 blind spot in miniature: the old aggregate said
`rhythm 1.00` because it saw one merged phrase; the per-line table now shows
four identical `4-4-4-4` cells. This is why the table exists.

### `quality.py`

Session 10 declares five objective targets in `quality_targets.json`:
`unbroken ≤10s`, `top_duration ≤60%`, `distinct bars ≥75%`,
`tessitura ≥C5 ≤60%`, pause hierarchy (min 0.5s, section end 1.0s, max
identical 40%, at least 3 distinct values).

| Case | Result |
|---|---|
| 08 | **FAIL**: top 78%, distinct 60%, tessitura 94%, pause 1 short gap |
| 09 final | **FAIL**: 4/5 pass; pause fails at 48% identical (0 short gaps, 7 distinct values) — this is the known 7–7.5 gap, not a hidden pass |
| example with lenient control targets | **PASS** (positive control; not the session target) |

The 09 final's only objective miss is the rest-variation gap. Session 10 must
bring `max identical` below 40% while keeping the gaps above the sidecar
targets.

### `repair.py`

- 08 report: maps `tessitura`, `duration spread`, `phrase plan` to the named
  bars/lines.
- Synthetic register/simultaneity report: maps register to bars 11, 22, 37–41,
  59, 65–69; overlap fixture maps simultaneity to bars 1–2.
- 09 final report: no FAIL/WARN rows; the full diagnostic map is still written.

### `abc_doctor.py`

- 09 final: **OK**.
- Mismatched block (Vocal 2 bars / Ins 1 bar): **FAIL** with
  “block bar counts differ: Vocal line 10 has 2 bars, Ins line 13 has 1” and
  the block-pairing hint.

### `verify_package.py`

- 09 final: **PASS**, 0 fail / 0 warn (score↔seed, Drums, core prefix, 10-line
  docs, plan, report).
- Unit tests cover `--state` (report hash + pass flag), `--review` (exactly 5
  numbered lines), and `--require-core-first` (core mtime before score).

## What this package is not

- It does not claim 9/10. The 09 final's pause variation still fails the quality
  target; that is the next experiment.
- The W5 fixtures are archived scores and synthetic cases, not a new
  composition. Session 10 is the composition experiment.
- No taste gate: `quality.py` checks only objective targets; the core critic
  (`references/critic.md`) is the taste layer.

## Folder contents

```text
session-10/
├── task.md
├── input/lyrics.txt
├── input/style.md
├── skills/abc-score-writer/   (0.7.0)
├── opencode.json
└── quality_targets.json
```

Do not put `CERTIFIED.md`, `PROMPT.txt`, analyst briefs, previous scores, or the
validation fixtures inside `session-10/`.
