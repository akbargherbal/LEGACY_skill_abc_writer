# session-14

The 0.9.0 meter pilot: same lyrics and model as session 13, one process
change — the live meter after every line, plus `--dry-run`, `--guard`,
per-bar `lint` overlap, `init` form-budget warning, `explain-metric`,
`align`, `view`, and `release --dry-run`. No task.md.

```bash
unzip session-14-ready.zip
cd session-14
opencode --auto
# paste PROMPT.txt (outside this directory)
```

Start clean: do not run `init` or create `plan.json`/`score.abc` before
the composer. It must run `init` itself and read the `FORM BUDGET` line.

What is pinned:

- `opencode.json` selects `deepseek/deepseek-flash#high` and `composer`.
- `.opencode/plugins/abc-guard.js` forces that model for every primary request
  and caps a model call at 8,000 output tokens; it appends the actual model to
  `abc-session.log`.
- `.opencode/agents/composer.md` has `steps: 40`, cannot edit
  `score.abc`, and must use the CLI.
- `.opencode/agents/verifier.md` is a read-only checker; `packager.md` owns the
  seed/docs after the score freezes.

After the run, export the chat JSON and measure:

```bash
python3 /path/to/skill_abc_writer/analysis/measure_session.py opencode_session_14.json \
  --score session-14/score.abc --max-ratio 10 --max-message 8000
```

Target: <=10x the final `score.abc` tokens, computed after the run; no message
above 8,000; 0 hand-written scripts; <=4 checker runs; 0 direct score writes.
`output + reasoning` is the numerator; seed/docs are diagnostics, not the ratio.
