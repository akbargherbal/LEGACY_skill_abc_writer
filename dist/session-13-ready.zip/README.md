# session-13

The stock-pass pilot: the 0.8.1 line workflow plus an optional phrase-level
asset bank. The composer still writes every line through `score_cli.py`; an
asset is a reference, declared in `loans.json`. There is no task.md.

```bash
unzip session-13-ready.zip
cd session-13
opencode --auto
# paste PROMPT.txt (outside this directory)
```

What is pinned:

- `opencode.json` selects `deepseek/deepseek-flash#high` and `composer`.
- `.opencode/plugins/abc-guard.js` forces that model for every primary request
  and caps a model call at 8,000 output tokens; it appends the actual model to
  `abc-session.log`.
- `.opencode/agents/composer.md` cannot edit `score.abc`; it must use the CLI.
- `.opencode/agents/verifier.md` is a read-only checker; `packager.md` owns the
  seed/docs after the score freezes.

After the run, export the chat JSON and measure:

```bash
python3 /path/to/skill_abc_writer/analysis/measure_session.py opencode_session_13.json \
  --score session-13/score.abc --max-ratio 10 --max-message 8000
```

Target: <=10x the final `score.abc` tokens, computed after the run; no message
above 8,000; 0 hand-written scripts; <=4 checker runs; 0 direct score writes.
`output + reasoning` is the numerator; seed/docs are diagnostics, not the ratio.
