# Session 09 — run/measure/stop checklist

**Skill:** `abc-score-writer` **0.6.0** (contract 0.4.0; checker/calibration
unchanged). Zip SHA-256 `a44644f6821eb5589e808fc24f7e710e7bb8ab49fa44875c05fa87b090b34888`.
**Model:** same as 08 (`deepseek-v4.1-flash-free` / `high`); do not change.
**Task:** `agent/task.md`, same D Kurd / 80 BPM lyrics as 06–08.
**Date:** 2026-11-24.

**Goal 1:** quality; the ear is the verdict (baseline 6/10, target 9/10).
**Goal 2:** economy; the artifact set is small, the process must be proportionate.

**This run tests 0.6.0:** one order, one checker policy, register 70,
`verify_package.py` + `craft.py`, `STATE.md`. The quality experiment has three
levers: register, qafla, rhythm; plus a new chorus opening.

---

## 0. Non-negotiables

- [ ] The ear decides the music; the checker is a diagnostic.
- [ ] No gate for taste; no metric as the goal.
- [ ] No retrieval: no exemplar, no phrase bank.
- [ ] Do not edit `checker.py`, `calibration.json` or `abc_tools.py`; do not
      modify the skill.
- [ ] Same input as 08: D Kurd, 80 BPM, same lyrics.

---

## 1. Clean room (before the prompt)

- [ ] The skill is installed and **loadable**; the first `skill` call succeeds.
      If it fails, stop: harness defect.
- [ ] The cwd contains **only** `task.md`, `input/` and `skills/`.
      No README, checklist, brief, analyst notes, exporter, or previous score.
- [ ] `task.md` is the 0.6.0 one-page task; it points to `SKILL.md §3`.
- [ ] Model + variant recorded; offline/no renderer recorded.
- [ ] Zip hash recorded: `a44644f6…b34888`; `selftest: PASS`.

---

## 2. Process checks

- [ ] `lyrics.txt` saved once; `syllabify.py --sections` run once; absolute
      `bar_start`/`bar_end`; no hand-typed offset table.
- [ ] `plan.json` targets from the example (register 70); bars/sections from
      `prosody.json`; `strict_shape: false`.
- [ ] `core_draft.abc` exists (8–16 bars) and is the opening of `score.abc`.
      **It is written before the full form; `seed_sheet.md` comes after.**
- [ ] `seed_sheet.md` is exactly 10 numbered lines, written **after**
      `score.abc`.
- [ ] `notes.md` is exactly 10 numbered lines.
- [ ] `score.abc` is two voices; `seed.abc` is the same Vocal/Ins + chords +
      `V: Drums`.
- [ ] **No custom ABC parser or statistics script.** The only checks are
      `checker.py`, `verify_package.py`, `craft.py`.
- [ ] `verify_package.py` PASS; `craft.py` report saved.
- [ ] `STATE.md` updated after each milestone.
- [ ] Checker runs: **≤4**; every run after a named fix; **stop after a pass**;
      no post-pass verification.
- [ ] Full score writes: **1** (2 max: one global sanity rewrite).
- [ ] No task list.

**Stop rule:** no `core_draft.abc` by the **8th composition call** (documentation
reads do not count) → stop and record "front-loaded".

**Budget stop (manual):** generated (`output + reasoning`) **≤ 52,460** = 10×
(score + seed). The analyst stops the run at that line; there is no automatic
monitor.

---

## 3. Measure exactly

From the native OpenCode export (`info.tokens`, `messages[].tokens`) and the
files:

| Field | Session 08 | Session 09 |
|---|---:|---:|
| Score tokens (`score.abc`) | 1,891 | |
| Seed tokens (`seed.abc`) | 3,355 | |
| Generated (`output + reasoning`) | 131,138 | |
| Ratio generated / (score + seed) | 25.0× | **≤10×** |
| Budget (10× score+seed) | 52,460 | 52,460 |
| Ratio generated / score only | 69.3× | diagnostic |
| Cache read / traffic | 98.68% | |
| Requests / tool calls | 70 / 68 | |
| Custom parser/stats scripts | 14 | **0** |
| Full score writes | 2 | **1** (2 max) |
| Checker runs | 7 | **≤4** |
| Quality (ear) | 6/10 | **≥6; target 9** |

- [ ] `cache_share = cache_read / (input + cache_read)`.
- [ ] Largest reasoning block: what it was doing.
- [ ] Every tool call counted; quote evidence for any finding.

---

## 4. Quality levers (the experiment)

- [ ] **Register:** verse 70–71, chorus 74–76; `tessitura ≥ C5 ≤ 0.60` (the
      plan is 70; the checker's sanity band stays 74 ± 5).
- [ ] **Qafla:** every section end and the final line holds a quarter or
      longer; `end_long` 0.25–0.50; the final note ≥ half a bar with a 3–5-note
      turn.
- [ ] **Rhythm:** break the eighth grid; `rhythm_variety ≥0.85`,
      `distinct_bar_share ≥0.75`, `top_duration ≤0.70`; repeated 26–35% with
      varied durations.
- [ ] **Chorus:** a new opening motif, not a sequence of the verse head; keep a
      distinct tail.
- [ ] The ear verdict is from a **Suno render of `seed.abc`**, not from the
      checker. If no audio, mark it pending.

---

## 5. Stop rules

- [ ] No core by the 8th composition call → stop.
- [ ] 52,460 generated → stop.
- [ ] A second full score write beyond the one global fix → stop.
- [ ] A checker run after a pass → stop.
- [ ] First `skill` call fails or cwd is dirty → the run is invalid; stop.

---

## 6. After the run

- [ ] Export the native OpenCode JSON.
- [ ] Compute the table in §3; read `report.json.measured`, `verify.json`,
      `craft.json`.
- [ ] Render `seed.abc` with Suno; listen; write the verdict.
- [ ] Report: `analysis/eval/reports/2026-11-25-deepseek-session-09.md`.
- [ ] Decision: if quality <6 → method/model; if generated >52,460 →
      contract/tool; no new gates.
