# Session 09 — ready package

Everything needed is already unpacked. Extract this archive and run.

## What is inside

```
session-09/
  agent/                         # OpenCode working directory
    task.md                      # the only prompt
    input/
      lyrics.txt
      style.md
    skills/
      abc-score-writer/          # 0.6.0, already unpacked
  README.md                      # this file
  checklist.md                   # run/measure/stop
  SESSION-09-BRIEF.md            # analyst only
  VERSION.txt                    # hashes
```

**Do not move `README.md`, `checklist.md` or `SESSION-09-BRIEF.md` into
`agent/`.** The agent's cwd must contain only `task.md`, `input/` and `skills/`.

## Setup (once, on the new machine)

```bash
cd session-09/agent

# 1. The skill is already unpacked; prove the tools work.
bash skills/abc-score-writer/scripts/selftest.sh | tail -3
# last line must be: selftest: PASS

# 2. Make the skill loadable by OpenCode's `skill` tool.
mkdir -p ~/.config/opencode/skills
ln -sfn "$PWD/skills/abc-score-writer" ~/.config/opencode/skills/abc-score-writer
readlink -f ~/.config/opencode/skills/abc-score-writer

# If symlinks are not allowed, copy instead:
# rm -rf ~/.config/opencode/skills/abc-score-writer
# cp -a skills/abc-score-writer ~/.config/opencode/skills/abc-score-writer
```

## Run

1. Open OpenCode **in `session-09/agent`** (not the parent folder; the 08 run
   opened the parent and the cwd was wrong).
2. Model: `deepseek-v4.1-flash-free`, variant `high`.
3. Tell the agent: `Read task.md and follow it.` Do not attach the README,
   checklist, brief or a previous score.
4. **The first `skill` call must succeed.** If it fails, stop and fix the
   install; it is a harness defect, not a skill result.
5. Watch it. There is no automatic monitor; stop manually at the budget.

## Stop rules

- No `core_draft.abc` by the **8th composition call** (documentation reads do
  not count) → stop; record "front-loaded".
- **52,460 generated** (`output + reasoning`) → stop.
- A second full `score.abc` write beyond the one global fix → stop.
- A checker run after a pass → stop.
- The run is invalid if the first `skill` call fails or the cwd is dirty.

## Success

- Quality ≥6/10 by ear (baseline), target 9.
- Generated / (score + seed) ≤10× = 52,460.
- 0 custom parser/stats scripts.
- 1 full score write (2 max: one global fix), ≤4 checker runs, no post-pass.
- `verify_package.py` PASS; `craft.py` report saved; all artifacts present.
- If no audio, mark the ear verdict pending; do not claim it.

## What to keep after the run

```
agent/score.abc
agent/seed.abc
agent/core_draft.abc
agent/plan.json
agent/phrases.json
agent/seed_sheet.md
agent/notes.md
agent/report.json
agent/verify.json
agent/craft.json
agent/STATE.md
agent/CHANGES.txt
agent/prosody.json
session.json        # opencode session export
audio/              # Suno render from seed.abc
```

The analyst reads `checklist.md` and `SESSION-09-BRIEF.md`; the agent does not.

## Version

`abc-score-writer` **0.6.0** — contract 0.4.0. See `VERSION.txt` for hashes.
The full release zip is `dist/abc-score-writer-0.6.0.zip` in the main repo;
this package is the already-unpacked session copy.
