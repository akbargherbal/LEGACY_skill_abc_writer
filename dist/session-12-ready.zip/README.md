# session-12

The same prompt as session 11, with one change: the composer writes the score
through `score_cli.py`, one lyric line at a time. There is no task.md.

```bash
unzip session-12-ready.zip
cd session-12
opencode --auto
# paste PROMPT.txt (outside this directory)
```

What is pinned:

- `opencode.json` selects `deepseek/deepseek-flash#high` and `composer`.
- `.opencode/plugins/abc-guard.js` forces that model for every primary request
  and caps a model call at 8,000 output tokens; it appends the actual model to
  `abc-session.log`.
- `.opencode/agents/composer.md` cannot edit `score.abc`; it must use the CLI.
- `.opencode/agents/verifier.md` is a read-only checker; `packager.md` owns the
  seed/docs after the score freezes.

After the run, export the chat JSON and measure:

```bash
python3 /path/to/skill_abc_writer/analysis/measure_session.py opencode_session_12.json \
  --score session-12/score.abc --max-ratio 10 --max-message 8000
```

Target: <=25,000 generated tokens (<=13x), stretch <=19,400 (10x); no message
above 8,000; 0 hand-written scripts; <=4 checker runs; 0 direct score writes.
