# Session 07 — DeepSeek instrumentation run

## The two goals (unchanged)

1. **Score excellence.** The ear is the verdict; the checker and the craft metrics
   are diagnostics.
2. **Token/cost efficiency.** Measure it, log it, do not cap it and do not trade
   the first goal for it.

This run serves **goal 2 first**, because after two Claude runs we still cannot
say where the tokens went. It is an instrumented run, not a verdict on the skill.

## What this run is

| | |
|---|---|
| Skill | `abc-score-writer` 0.5.2, **frozen** |
| Task | `task.md`, same brief as session 06: D Kurd, 80 BPM, same 26 lines |
| Checker / calibration | unchanged |
| Harness | OpenCode |
| Model | `deepseek-v4-pro` variant `max` (recommended) or `deepseek-flash` `high` |

**Only the model and the harness change.** The task, lyrics, key, tempo, skill
and checker are identical to session 06. Therefore:

- The **score is not comparable to Claude's**: DeepSeek is a different composer.
  A weak score here does not prove the skill is broken, and a good one does not
  prove it is fixed.
- The **token pattern is comparable**: same skill, same prompt, same artifacts.

## Why this environment

OpenCode stores, for every step: `input`, `output`, `reasoning`, `cache.read`,
`cache.write`, `cost`, the finish reason, and the **full reasoning text**. The
Claude export had none of these; every token figure in the session-06 report is
an estimate from character counts. Here they are measured.

That also lets us separate three things the last report could not:

| Quantity | What it means |
|---|---|
| prompt traffic (`input + cache.read`) | context pressure; what the model re-read |
| cache read | billed at a fraction of input; not the same as fresh tokens |
| output + reasoning | the likely driver of a session allowance |

The session-06 report attributed 82.6% of *traffic* to documentation. If most of
that is cache reads, the **cost** share is much smaller. This run settles it.

## How to run

1. Install the skill as `abc-score-writer` in the harness's skill directory
   (global or project-local). The prompt contains no machine path: it refers to
   `<skill>` as "the directory that contains the `SKILL.md` you loaded".
2. Choose the model: `deepseek-v4-pro` + `max`, or `deepseek-flash` + `high`.
3. Start a **new** session in a fresh, empty working directory. The prompt says
   "work in the current directory", so every deliverable lands there.
4. Paste `task.md` verbatim. Do not attach a previous score, seed, sheet or
   checklist. Do not add "be strict", "0 warnings", or a token cap.
5. Let it finish. There is no 5-hour allowance to hit; the run costs cents.
6. Export with OpenCode's native command (no custom script needed):

```bash
opencode session list                         # find the session id
opencode session export <ses_id> > session.json
```

`opencode session export` prints the JSON to stdout. Do not pass `--sanitize`
for analysis: it redacts the transcript and file data.

## What to keep

```
<run-dir>/
  output/        score.abc, seed.abc, core_draft.abc, plan.json,
                 phrases.json, seed_sheet.md, notes.md, report.json
  export/        session.json   ← native export: tokens, reasoning, tools
  audio/         A-no-seed.mp3, B-v2-seed.mp3, C-new-seed.mp3
```

## Stop rules

- **No ABC by the 10th tool call** → stop and record "process still
  front-loaded". Do not wait for another 20-minute design block.
- **`score.abc` rewritten twice before `seed.abc` exists** → note it as the
  self-check loop, but let it run; with visible reasoning this is the behaviour
  we are trying to catch.
- **First deliverable order**: `score.abc` before `seed.abc` before `notes.md`.
  If it writes notes first, record it.

## What success looks like

- A complete deliverable set: score, seed with `V: Drums`, notes, one checker run.
- An exact `session.json`: prompt traffic, cache read, output, reasoning, cost,
  finish reasons.
- A `reasoning.md` we can read: does the 10-minute block compose the whole piece?
  Does the self-check come from the plan targets or from listening?
- Then, and only then, the blind A/B/C listen for goal 1.

The score itself is graded by ear, as always. The cost is logged, not capped.
