Load the `abc-score-writer` skill before you start.

Work in the current directory and create every file there.

Compose an ABC score and a Suno seed from the lyrics and style below. This is a
lean pass: music first, notes after. D Kurd (K:Dm, `_E` for the b2), 80 BPM,
4/4. The lyrics are vocalised; the harakat carry the count. Do not retrieve an
exemplar or a phrase bank.

1. Save the block below once as `lyrics.txt`. Run the bundled syllabifier once:
   `python3 <skill>/scripts/syllabify.py lyrics.txt --tempo 80 --json prosody.json --phrases phrases.json`
   where `<skill>` is the directory that contains the `SKILL.md` you loaded.
   Use its bar budget and line table. Do not retype the table by hand.
2. Write a 10-line `seed_sheet.md`: frame, cell, period rule, cadence rule,
   melisma rule, riff, subtraction, one 2-bar groove per section, three
   interaction events, the weakest bar. Rules, not per-line results;
   `phrases.json` owns the table. Then write the skill's `plan.json`: set key,
   tempo, bars, syllables, sections and maqam; leave the gate targets at the
   template defaults.
3. Write an 8–16 bar `core_draft.abc`: the cell, the period, the groove. Hum
   it, fix the weakest bar, then expand.
4. Write `score.abc` (Vocal + Ins, two voices) and `seed.abc` (same melody,
   chords, and a `V: Drums` voice: a 2-bar groove per section, a fill at the end
   of a 4- or 8-bar group, drums out for the last line).
5. Run the checker once at the end. Then write a 10-line `notes.md`: the cell,
   the cadence rule, the three events, what you fixed, and the three moments a
   listener should notice.

Do not create a task list. Do not read `checker.py`, `abc_tools.py` or
`calibration.json`. Do not add a third voice to `score.abc`. Do not use the
checker as the goal; the ear is the verdict. If the renderer cannot read the
drum voice, say so; the vocal phrasing still has to imply the groove.

Lyrics and style:

```
classical arabic, melismatic, microtonal ornaments, belting, tarab, emotive expressive delivery, symphonic metal, powerful operatic performance, rhythm guitar, epic, clear enunciation, vocal-forward mix, crisp consonants, audiophile, call and response, backing vocals, Maqam Kurd, mood: "somber, torment, night dread"

[Intro | single clean guitar | close-mic'd, plate reverb, short decay]
اعْتَضْتُ مِنْ وَجْهِ خِلِّي بَعْدَ فُرْقَتِهِ كَأْسًا
يُجَرَّعُ مِنْهَا مَا أُجَرَّعُهُ...

[Verse 1 | dark brooding vocals | muted rhythmic guitars and heavy bass]
اعْتَضْتُ مِنْ وَجْهِ خِلِّي بَعْدَ فُرْقَتِهِ كَأْسًا
يُجَرَّعُ مِنْهَا مَا أُجَرَّعُهُ...
كَمْ قَائِلٍ لِي ذُقْتَ الْبَيْنَ قُلْتُ لَهُ
الذَّنْبُ وَاللَّهِ ذَنْبِي لَسْتُ أَدْفَعُهُ...
أَلَا أَقَمْتَ فَكَانَ الرُّشْدُ أَجْمَعُهُ
لَوْ أَنَّنِي يَوْمَ بَانَ الرُّشْدُ أَتْبَعُهُ...
لَوْ أَنَّنِي لَمْ تَقَعْ عَيْنِي عَلَى بَلَدٍ
فِي سَفْرَتِي هَـٰذِهِ إِلَّا وَأَقْطَعُهُ...
إِنِّي لَأَقْطَعُ أَيَّامِي وَأُنْفِدُهَا
بِحَسْرَةٍ مِنْهُ فِي قَلْبِي تُقَطِّعُهُ...

[Chorus | anguished powerful vocals | heavy orchestral swell and distorted guitars — Kurd]
مَا كُنْتُ أَحْسَبُ أَنَّ الدَّهْرَ يَفْجَعُنِي بِهِ
وَلَا أَنَّ بِي الْأَيَّامَ تَفْجَعُهُ...

[Verse 2]
بِمَنْ إِذَا هَجَعَ النُّوَّامُ بِتُّ لَهُ
بِلَوْعَةٍ مِنْهُ لَيْلِي لَسْتُ أَهْجَعُهُ...
لَا يَطْمَئِنُّ لِجَنْبِي مَضْجَعٌ وَكَذَا
لَا يَطْمَئِنُّ لَهُ مُذْ بِنْتُ مَضْجَعُهُ...
حَتَّى جَرَى الْبَيْنُ فِيمَا بَيْنَنَا بِيَدٍ عَسْرَاءَ
تَمْنَعُنِي حَظِّي وَتَمْنَعُهُ...
قَدْ كُنْتُ مِنْ رَيْبِ دَهْرِي جَازِعًا فَرِقًا
فَلَمْ أُوَقَّ ٱلَّذِي قَدْ كُنْتُ أَجْزَعُهُ...

[Chorus]
مَا كُنْتُ أَحْسَبُ أَنَّ الدَّهْرَ يَفْجَعُنِي بِهِ
وَلَا أَنَّ بِي الْأَيَّامَ تَفْجَعُهُ...

[Outro | deep male vocals | clean electric guitar]
قَدْ كُنْتُ مِنْ رَيْبِ دَهْرِي جَازِعًا فَرِقًا
فَلَمْ أُوَقَّ ٱلَّذِي قَدْ كُنْتُ أَجْزَعُهُ...
```
