# Session 07 — analyst notes

**Do not paste this file into the agent.**

## Purpose

Session 07 is an **instrumentation run**, not a skill experiment. It exists
because the Claude export could not answer four questions. Keep the two goals in
order: the ear decides the music; the numbers only tell us what the process cost.

## What the last two runs measured

| | Session 05 | Session 06 |
|---|---:|---:|
| Requests / calls | 15 / 21 | 15 / 14 |
| Prompt traffic (estimated) | 327 k | 291 k |
| Skill share of traffic | 52.6% | 61.6% |
| Docs share of traffic | 81.7% | 82.6% |
| Hidden thinking | 19.7 min, 202 seg | 12.8 min, 144 seg |
| First ABC | never | call 11 (core), 12 (score) |
| Deliverables | sheet + plan | sheet, plan, core, score |
| Checker runs | 0 | 0 |

Both runs were stopped mid-turn. Neither ran out of context (final context
31 k / 29 k). The likely cause is the session's output/usage allowance, but the
export cannot prove it.

## Four hypotheses to test against `reasoning.md`

**H1 — the whole piece is composed in one hidden block.**
Look for bar-by-bar or section-by-section planning before the first file write,
and for repeated bar arithmetic. In 05 that block was 19.7 min; in 06, 600 s
followed by an 11-second sheet write. If the reasoning shows the complete piece
already decided before `seed_sheet.md`, the sheet-first vs score-first debate is
settled: the sheet is a transcript, not a plan.

**H2 — the self-check is driven by the plan targets, not by the ear.**
Look for `max_top_duration_share`, `repeat share`, `chorus lift`, `0.65`,
`min_distinct_durations` — the plan's gate numbers — appearing *before* any
attempt to sing or hum the cell. In 06 this produced a home-made stats script and
a full rewrite of a complete score. If the reasoning contains no listening
language, the loop is metric-shaped.

**H3 — documentation is a cost sink only if it is not cached.**
The session export separates `input` from `cache_read`. Compute:
`cache_share = cache_read / (input + cache_read)`.
If it is above ~90%, the 43.5 KB skill is cheap in dollars and the quota driver is
output/reasoning — which would **falsify the emphasis** of the session-06 report
and move the next change from "split the skill" to "checkpointed deliverables".
Do not skip this check.

**H4 — the 26-row table returns.**
`syllabify.py --phrases` emits `body_bar_start/end` and asks for absolute
`bar_start/bar_end`. If the agent hand-types 26 ranges again, this is a tool
defect, not a prompt defect, and it should be fixed in the script.

## The model caveat

DeepSeek is not Claude. Do **not** read a weak score as evidence that 0.5.2 is
bad, and do not read a good one as evidence that the token problem is solved.
The comparable quantities are the process and the cost, not the melody.

## Exact fields to record

From `export/session.json` (`info.tokens`, `messages[].tokens`):

- `totals.requests`, `totals.prompt_traffic`, `totals.cache_read`,
  `totals.output`, `totals.reasoning`, `totals.cost_usd`,
  `totals.reasoning_share_of_output`
- `per_message[*].finish` — `stop`, `length`, `tool-calls`, `error`
- `tools[*]` — call counts and I/O chars per tool
- `steps[*]` — the per-request token rows; this is the new table for the report

From the `reasoning` parts of `session.json`:

- time and char count of the largest block
- what it spends the block on (composition, arithmetic, schema hunting)
- whether the first ABC is preceded by a complete mental score

## Decision tree after the run

| Finding | Next one-change run |
|---|---|
| Cache share > 90%, reasoning is most of output | Checkpointed deliverables (score → seed → notes), not the skill split |
| Cache share < 70%, docs dominate | Split the skill (0.5.3) |
| Reasoning shows whole-piece composition before any file | The sheet/plan step needs a hard intermediate artifact, not more prose |
| 26-row table typed again | Fix `syllabify.py` to emit absolute bars |
| Complete deliverables, ear rejects the drums | The seed contract, not the prose |

One change per run. No new gate for taste. No metric as a goal.
