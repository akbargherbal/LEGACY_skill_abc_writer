# session-16

The 1.0 whole-draft loop in a clean room: `init` -> whole draft -> scorecard
-> whole rewrite -> scorecard -> seams -> release. One process change from
session 15: thinking is **low**, not high. Steps: 100. Skill: 1.0.0.
Agent: whole-draft `composer.md`.

```bash
unzip session-16-ready.zip
cd session-16
opencode --auto
# paste PROMPT.txt (outside this directory)
```

Start in a **new empty directory**. The zip has no `plan.json`,
`phrases.json` or `score.abc`. If you unzip over an old folder, stale files
survive and `init` will refuse to run; that is a dirty run, not a composer
error.

What is pinned:

- `opencode.json` selects `deepseek/deepseek-flash#low` and `composer`.
- `.opencode/plugins/abc-guard.js` forces that model and variant on every
  primary request, caps a call at 8,000 output tokens, and appends the actual
  model to `abc-session.log`.
- `.opencode/agents/composer.md` has `steps: 100` and may write
  `score.abc` only as a whole file.
- `.opencode/agents/verifier.md` is a read-only checker; `packager.md` owns
  the seed/docs after the score freezes.

Run validity (check before interpreting anything):

1. `init` runs and prints `FORM BUDGET: 64 bars vs syllabify 82 (-22%)`.
2. The composer keeps 64 or reruns with `--force --bars 82 --sections`; a
   bare `--bars` is a form error.
3. One session id; export the complete chat JSON.
4. The score is written whole; no `sed`/Python edits of `score.abc`.

After the run, export the chat JSON and measure:

```bash
python3 /path/to/skill_abc_writer/analysis/measure_session.py opencode_session_16.json \
  --score session-16/score.abc --max-ratio 10 --max-message 8000
```

Target: generated (`output + reasoning`) <=10x the final `score.abc` tokens;
0 blocking at release; at most 4 whole drafts; no patch-by-bar. Seed/docs are
diagnostics, not the ratio.

Known false warning: `section plan metrics` uses the auto plan's `[0,3]`
`vocal_notes_per_bar` band, which is too low for dense syllabic verse. Do not
rewrite the score to chase it.
