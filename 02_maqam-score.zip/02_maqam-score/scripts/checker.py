#!/usr/bin/env python3
"""Check a composed score against its plan, and print the numbers to report.

This is the skill's only verifier. It runs the vendored runtime parser
(`scripts/abc_tools.py`, a copy of `plumbing/yue2_instrumental/abc_tools.py`)
first and fails closed: anything the renderer cannot read is an error here, not
a warning. Then it measures the plan's quality targets.

    python3 checker.py score.abc --plan plan.json
    python3 checker.py score.abc --plan plan.json --json report.json

Hard checks (exit 1): runtime dialect, complete plan, one meter, complete bars,
both voices, declared sections and bar count, zero simultaneity (or one declared
bar), notes per syllable within the declared melisma floor/ceiling, cadence on
the tonic, a final full-bar rest in both voices, plus the plan's register,
duration-spread, duration-variety, ties, fill-length, Ins-activity and chord
targets. Warnings never fail: they are corpus comparisons worth reading.

No network, no audio, no ABC toolchain. Standard library only.
"""
from __future__ import annotations

import argparse
import json
import math
import re
import statistics
import sys
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

# The runtime parser is vendored next to this file. It is the contract the
# renderer actually reads, so it runs first and fails closed. Do not replace it
# with the lenient metric parser below.
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))
import abc_tools as runtime_abc  # noqa: E402

VOICES = ("Vocal", "Ins")
DURATIONS = {1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48}
NATURAL = dict(zip("CDEFGAB", (0, 2, 4, 5, 7, 9, 11)))
KEYS = {
    **dict(zip(("Cb", "Gb", "Db", "Ab", "Eb", "Bb", "F", "C", "G", "D", "A", "E", "B", "F#", "C#"),
                range(-7, 8))),
    **dict(zip(("Abm", "Ebm", "Bbm", "Fm", "Cm", "Gm", "Dm", "Am", "Em", "Bm", "F#m", "C#m",
                "G#m", "D#m", "A#m"), range(-7, 8))),
}
TOKEN = re.compile(
    r'"(?P<chord>[^"\n]*)"|'
    r"(?P<acc>\^\^|__|\^|_|=)?(?P<note>[A-Ga-gz])"
    r"(?P<oct>[,']*)(?P<dur>[0-9]*)(?P<tie>-?)"
)
VOICE_HEADER = {
    "Vocal": 'V: Vocal clef=treble name="Vocal Melody" snm="Vocal"',
    "Ins": 'V: Ins clef=treble name="Ins Melody" snm="Inst."',
}


class AbcError(ValueError):
    pass


@dataclass
class Note:
    onset: int          # L-units from the start of the score
    dur: int            # L-units
    pitch: int          # MIDI
    bar: int            # 1-based
    section: str
    tied: bool = False


@dataclass
class Score:
    unit_den: int
    tempo: float
    meter: tuple[int, int]
    key: str
    notes: dict[str, list[Note]] = field(default_factory=dict)
    bar_sections: list[str] = field(default_factory=list)
    chords: int = 0

    @property
    def units_per_bar(self) -> int:
        n, d = self.meter
        return int(self.unit_den * n / d)

    @property
    def n_bars(self) -> int:
        return len(self.bar_sections)

    @property
    def seconds(self) -> float:
        quarters = self.n_bars * self.units_per_bar / (self.unit_den / 4)
        return quarters * 60 / self.tempo


def key_map(key: str) -> dict[str, int]:
    if key not in KEYS:
        raise AbcError(f"unsupported key {key!r}: use a standard major or minor K: field")
    count = KEYS[key]
    alter = {letter: 0 for letter in NATURAL}
    for letter in ("FCGDAEB" if count > 0 else "BEADGCF")[:abs(count)]:
        alter[letter] = 1 if count > 0 else -1
    return alter


def tonic_pc(key: str) -> int:
    m = re.match(r"([A-G])([#b]?)", key)
    if not m:
        raise AbcError(f"cannot read the tonic from K:{key}")
    return (NATURAL[m.group(1)] + (1 if m.group(2) == "#" else -1 if m.group(2) == "b" else 0)) % 12


def key_scale(key: str) -> set[int]:
    alter = key_map(key)
    return {(NATURAL[letter] + alter[letter]) % 12 for letter in NATURAL}


def _split_music(voice: str, s: str) -> list[str]:
    """One music line -> blocks; ['Z'] entries are expanded later."""
    if not s.endswith("|"):
        raise AbcError(f"{voice}: music line must end with a plain '|': {s[:40]!r}")
    bodies = [b.strip() for b in s.split("|")[:-1]]
    if not bodies or any(not b for b in bodies):
        raise AbcError(f"{voice}: empty measure or unsupported barline in {s[:40]!r}")
    out: list[str] = []
    for body in bodies:
        rest = re.fullmatch(r"Z([2-4])?", body)
        out.extend(["Z"] * int(rest.group(1) or 1) if rest else [body])
    if not 1 <= len(out) <= 4:
        raise AbcError(f"{voice}: a block must hold 1-4 measures after Z expansion")
    return out


def parse(text: str) -> Score:
    lines = text.splitlines()
    if len(lines) < 9:
        raise AbcError("incomplete score: expected the 8-line native header and music")
    if lines[0] != "X:1" or lines[1] != "T:":
        raise AbcError("header must start with exactly 'X:1' then 'T:'")
    m = re.fullmatch(r"M:([1-9][0-9]*)/([1-9][0-9]*)", lines[2])
    if not m:
        raise AbcError(f"missing or unsupported M: line: {lines[2]!r}")
    meter = (int(m.group(1)), int(m.group(2)))
    m = re.fullmatch(r"L:1/([1-9][0-9]*)", lines[3])
    if not m:
        raise AbcError(f"missing or unsupported L: line: {lines[3]!r}")
    unit_den = int(m.group(1))
    m = re.fullmatch(r"Q:1/4=([1-9][0-9]*)", lines[4])
    if not m:
        raise AbcError(f"missing or unsupported Q: line: {lines[4]!r}")
    tempo = float(m.group(1))
    for i, name in enumerate(VOICES, start=5):
        if lines[i] != VOICE_HEADER[name]:
            raise AbcError(f"line {i + 1}: expected exactly {VOICE_HEADER[name]!r}")
    if not lines[7].startswith("K:") or len(lines[7]) < 3:
        raise AbcError("missing K: key line after the voice declarations")
    key = lines[7][2:].strip()
    key_map(key)

    # Gather (section, voice, bars) blocks; the dialect alternates the voices,
    # so every Vocal block is answered by one Ins block of the same length.
    blocks: list[tuple[str, str, list[str]]] = []
    section = "score"
    for raw in lines[8:]:
        s = raw.strip()
        if not s:
            continue
        if s.startswith("%"):
            # A comment inside a Vocal block ("% line 2") is an annotation.
            # Only a comment outside the pair changes the section.
            if blocks and blocks[-1][1] == "Vocal":
                continue
            section = re.sub(r"\s+", " ", s.lstrip("%").strip().lower()) or "section"
            continue
        if re.match(r"^[MK]:", s):
            raise AbcError("inline M:/K: change inside the body: a composed score "
                           "keeps one M: and one K:")
        if s.startswith("V:"):
            name = s[2:].strip().split()[0]
            if name not in VOICES:
                raise AbcError(f"unknown voice {name!r}; only Vocal and Ins are allowed")
            blocks.append((section, name, []))
            continue
        if not blocks:
            raise AbcError(f"music before any V: block: {s[:40]!r}")
        blocks[-1][2].extend(_split_music(blocks[-1][1], s))

    if not blocks:
        raise AbcError("no music after the header")
    for i, (sec, name, _) in enumerate(blocks):
        want = VOICES[i % 2]
        if name != want:
            raise AbcError(f"block {i + 1}: expected V: {want} (voices alternate Vocal, Ins)")
    if len(blocks) % 2:
        raise AbcError("the last Vocal block has no Ins block")
    for i in range(0, len(blocks), 2):
        (s1, _, a), (s2, _, b) = blocks[i], blocks[i + 1]
        if s1 != s2:
            raise AbcError(f"block {i + 1}: a section marker falls between the two voices")
        if len(a) != len(b):
            raise AbcError(f"block {i + 1}: Vocal has {len(a)} bars, Ins has {len(b)}")

    score = Score(unit_den, tempo, meter, key, {v: [] for v in VOICES})
    step = score.units_per_bar
    bar_no = 0
    for i in range(0, len(blocks), 2):
        sec, _, vocal_bars = blocks[i]
        _, _, ins_bars = blocks[i + 1]
        for vb, ib in zip(vocal_bars, ins_bars):
            bar_no += 1
            score.bar_sections.append(sec)
            for name, body in (("Vocal", vb), ("Ins", ib)):
                _parse_bar(score, name, body, bar_no, sec, step)
    return score


def _parse_bar(score: Score, voice: str, body: str, bar_no: int, section: str, step: int) -> None:
    start = (bar_no - 1) * step
    offset = 0
    local: dict[str, int] = {}
    alter = key_map(score.key)
    pending = getattr(score, "_pending", {}).get(voice)
    if body == "Z":
        if pending is not None:
            raise AbcError(f"{voice} bar {bar_no}: tie enters a full-measure rest")
        offset = step
    else:
        cursor = 0
        while cursor < len(body):
            if body[cursor].isspace():
                cursor += 1
                continue
            m = TOKEN.match(body, cursor)
            if not m:
                raise AbcError(f"{voice} bar {bar_no}: unsupported token at "
                               f"{body[cursor:cursor + 24]!r}")
            cursor = m.end()
            chord = m.group("chord")
            if chord is not None:
                if voice != "Vocal":
                    raise AbcError(f"{voice} bar {bar_no}: chord symbols belong in Vocal")
                if offset >= step:
                    raise AbcError(f"{voice} bar {bar_no}: chord after the bar end")
                score.chords += 1
                continue
            note, acc, octave = m.group("note"), m.group("acc"), m.group("oct")
            units, tie = int(m.group("dur") or "1"), bool(m.group("tie"))
            if units not in DURATIONS:
                raise AbcError(f"{voice} bar {bar_no}: duration {units} unsupported; use "
                               "1,2,3,4,6,8,12,16,24,32,48 and tie to split others")
            if offset + units > step:
                raise AbcError(f"{voice} bar {bar_no}: event passes the bar end")
            if "," in octave and "'" in octave:
                raise AbcError(f"{voice} bar {bar_no}: mixed octave marks")
            if note == "z":
                if acc or octave or tie:
                    raise AbcError(f"{voice} bar {bar_no}: a rest cannot carry marks or a tie")
                if pending is not None:
                    raise AbcError(f"{voice} bar {bar_no}: tie enters a rest")
            else:
                letter = note.upper()
                written = 60 + NATURAL[letter] + (12 if note.islower() else 0)
                written += 12 * (octave.count("'") - octave.count(","))
                value = local.get(letter, alter[letter])
                if acc:
                    value = {"=": 0, "_": -1, "__": -2, "^": 1, "^^": 2}[acc]
                    local[letter] = value
                pitch = written + value
                if not 0 <= pitch <= 127:
                    raise AbcError(f"{voice} bar {bar_no}: pitch outside MIDI range")
                if pending is not None:
                    old_pitch, old_written, old_note = pending
                    if not acc and written == old_written:
                        pitch = old_pitch
                    if pitch != old_pitch:
                        raise AbcError(f"{voice} bar {bar_no}: tie changes pitch "
                                       f"{old_pitch} -> {pitch}")
                    old_note.dur += units
                    old_note.tied = True
                else:
                    score.notes[voice].append(Note(start + offset, units, pitch, bar_no, section))
                pending = (pitch, written, score.notes[voice][-1]) if tie else None
            offset += units
    if offset != step:
        raise AbcError(f"{voice} bar {bar_no}: sums to {offset}/{step} L-units")
    if not hasattr(score, "_pending"):
        score._pending = {}
    score._pending[voice] = pending


def finish(score: Score) -> None:
    for name in VOICES:
        if getattr(score, "_pending", {}).get(name) is not None:
            raise AbcError(f"{name}: unresolved tie at the end of the score")


def phrase_split(notes: list[Note], units_per_bar: int) -> list[list[Note]]:
    out: list[list[Note]] = []
    cur: list[Note] = []
    prev_end = None
    for note in notes:
        if cur and (note.section != cur[-1].section
                    or note.onset - prev_end >= units_per_bar / 4):
            out.append(cur)
            cur = []
        cur.append(note)
        prev_end = note.onset + note.dur
    if cur:
        out.append(cur)
    return [p for p in out if len(p) >= 2]


def check(score: Score, plan: dict, runtime_ok: bool = True, plan_present: bool = True) -> tuple[list[tuple[str, str, bool, str]], dict]:
    vocal, ins = score.notes["Vocal"], score.notes["Ins"]
    results: list[tuple[str, str, bool, str]] = []
    if runtime_ok:
        results.append(("PASS", "runtime parse", True,
                        "abc_tools.parse accepted the file"))

    def hard(name: str, ok: bool, detail: str) -> None:
        results.append(("PASS" if ok else "FAIL", name, bool(ok), detail))

    def warn(name: str, ok: bool, detail: str) -> None:
        results.append(("PASS" if ok else "WARN", name, True, detail))

    hard("key", "key" not in plan or score.key == plan["key"],
         f"K:{score.key}" + (f" (plan {plan['key']})" if "key" in plan else ""))
    hard("meter", "meter" not in plan or plan["meter"] == f"{score.meter[0]}/{score.meter[1]}",
         f"{score.meter[0]}/{score.meter[1]}"
         + (f" (plan {plan['meter']})" if "meter" in plan else ""))
    hard("unit", "unit" not in plan or plan["unit"] == f"1/{score.unit_den}",
         f"L:1/{score.unit_den}" + (f" (plan {plan['unit']})" if "unit" in plan else ""))
    hard("tempo", "tempo" not in plan or abs(score.tempo - float(plan["tempo"])) < 1e-9,
         f"Q:{score.tempo:g}" + (f" (plan {plan['tempo']})" if "tempo" in plan else ""))
    bars = plan.get("bars")
    hard("bars", bars is None or int(bars) == score.n_bars,
         f"{score.n_bars}" + (f" (plan {bars})" if bars is not None else ""))

    required = ("key", "tempo", "meter", "unit", "bars", "syllables", "sections",
                "melisma_min", "melisma_max", "register", "max_top_duration_share",
                "min_distinct_durations", "ties_min", "min_fill_notes", "chords_min")
    missing = [k for k in required if k not in plan]
    if plan_present:
        hard("plan targets", bool(plan) and not missing,
             "complete" if bool(plan) and not missing else ("empty plan" if not plan else "missing: " + ", ".join(missing)))
    else:
        hard("plan targets", False,
             "missing --plan: every score requires a plan with quality targets")

    want = [re.sub(r"\s+", " ", str(s).strip().lower()) for s in plan.get("sections", [])]
    got = [re.sub(r"\s+", " ", s) for s in score.bar_sections]
    got = [s for i, s in enumerate(got) if i == 0 or s != got[i - 1]]
    hard("sections", not want or got == want,
         " -> ".join(got) if not want or got == want
         else f"score {got} != plan {want}")

    overlaps = []
    for v in vocal:
        for i in ins:
            start, end = max(v.onset, i.onset), min(v.onset + v.dur, i.onset + i.dur)
            if end > start:
                overlaps.append((v.bar, end - start))
    overlap_units = sum(u for _, u in overlaps)
    exception = plan.get("simultaneity_exception")
    ok = (not overlaps) or (exception is not None
                            and all(b == int(exception) for b, _ in overlaps)
                            and overlap_units <= 4)
    hard("simultaneity", ok,
         f"{overlap_units} overlapping sixteenths"
         + (f" in bars {sorted({b for b, _ in overlaps})}" if overlaps else "")
         + f" (declared exception: {exception})")

    syllables = plan.get("syllables")
    if syllables:
        ratio = len(vocal) / syllables
        floor = float(plan.get("melisma_min", 1.0))
        budget = float(plan.get("melisma_max", 1.3))
        hard("notes per syllable", floor <= ratio <= budget,
             f"{len(vocal)}/{syllables} = {ratio:.2f} (budget {floor:.2f}-{budget:.2f})")

    # --- corpus-shape gates (declared in the plan) -------------------------
    vp = [n.pitch for n in vocal]
    reg = plan.get("register")
    if reg:
        target_mean = float(reg.get("mean", 74))
        tolerance = float(reg.get("tolerance", 4))
        mean_pitch = statistics.mean(vp) if vp else 0.0
        hard("register mean", abs(mean_pitch - target_mean) <= tolerance,
             f"mean {mean_pitch:.1f} vs target {target_mean:g} +/- {tolerance:g}")
        target_top = reg.get("top")
        if target_top is not None:
            hard("register top", bool(vp) and max(vp) >= int(target_top),
                 f"top {max(vp) if vp else '-'} vs target >={target_top}")

    durations = [n.dur for n in vocal]
    duration_counts = Counter(durations)
    top_duration_share = (max(duration_counts.values()) / len(durations)
                          if durations else None)
    if "max_top_duration_share" in plan and top_duration_share is not None:
        cap = float(plan["max_top_duration_share"])
        hard("duration spread", top_duration_share <= cap,
             f"most common duration {top_duration_share:.0%} of notes (max {cap:.0%})")
    if "min_distinct_durations" in plan:
        floor_n = int(plan["min_distinct_durations"])
        hard("duration variety", len(duration_counts) >= floor_n,
             f"{len(duration_counts)} distinct durations (min {floor_n})")

    ties = sum(1 for n in vocal if n.tied)
    if "ties_min" in plan:
        hard("ties", ties >= int(plan["ties_min"]),
             f"{ties} tied vocal notes (min {plan['ties_min']})")

    last_pc = vocal[-1].pitch % 12 if vocal else None
    hard("cadence on tonic", last_pc == tonic_pc(score.key),
         f"final pc {last_pc}, tonic {tonic_pc(score.key)}")

    last_bar = score.n_bars
    bar_start = (last_bar - 1) * score.units_per_bar
    bar_end = last_bar * score.units_per_bar
    sounding_in_final = [n for n in vocal + ins
                         if n.onset < bar_end and n.onset + n.dur > bar_start]
    final_rest = not sounding_in_final
    hard("final rest", final_rest,
         f"final bar {last_bar}: " + ("rest in both voices" if final_rest
                                     else "has notes; end with Z| in both voices"))

    phrases = phrase_split(vocal, score.units_per_bar)
    section_end: dict[str, int] = {}
    for i, sec in enumerate(score.bar_sections, 1):
        section_end[sec] = max(section_end.get(sec, 0), i * score.units_per_bar)
    answered: dict[str, list[int]] = {}
    answer_lengths: list[int] = []
    for i, phrase in enumerate(phrases):
        start = phrase[-1].onset + phrase[-1].dur
        nxt = (phrases[i + 1][0].onset if i + 1 < len(phrases)
               else section_end[phrase[-1].section])
        if nxt - start < 4:
            continue
        candidates = [n for n in ins if start <= n.onset < nxt]
        answered.setdefault(phrase[-1].section, []).append(int(bool(candidates)))
        if candidates:
            answer_lengths.append(len(candidates))

    sung_sections = {n.section for n in vocal}
    fills: list[list[Note]] = []
    for note in [n for n in ins if n.section in sung_sections]:
        if fills and note.section == fills[-1][-1].section and \
                note.onset - (fills[-1][-1].onset + fills[-1][-1].dur) <= 4:
            fills[-1].append(note)
        else:
            fills.append([note])
    shapes = [tuple(b.pitch - a.pitch for a, b in zip(f, f[1:])) for f in fills if len(f) > 1]
    shape_counts = {s: shapes.count(s) for s in set(shapes)}

    if "min_fill_notes" in plan and (answer_lengths or fills):
        floor_n = int(plan["min_fill_notes"])
        groups = answer_lengths or [len(f) for f in fills]
        shortest = min(groups)
        hard("answer fill length", shortest >= floor_n,
             f"shortest answer {shortest} notes (min {floor_n}); lengths {groups}")

    ins_active = (len({n.bar for n in ins}) / score.n_bars) if score.n_bars else 0.0
    if "ins_active_share_min" in plan:
        floor_share = float(plan["ins_active_share_min"])
        hard("ins activity", ins_active >= floor_share,
             f"Ins sounds in {ins_active:.0%} of bars (min {floor_share:.0%})")

    if "chords_min" in plan:
        hard("chords", score.chords >= int(plan["chords_min"]),
             f"{score.chords} chord symbols (min {plan['chords_min']})")
    elif score.chords == 0:
        warn("chords", False,
             "0 chord symbols; the measured takes carry about 1.2 per bar")

    def register(notes: list[Note]) -> str:
        if not notes:
            return "-"
        ps = [n.pitch for n in notes]
        return f"{min(ps)}-{max(ps)} mean {statistics.mean(ps):.0f}"

    sec_bars: dict[str, int] = {}
    for sec in score.bar_sections:
        sec_bars[sec] = sec_bars.get(sec, 0) + 1
    scale = key_scale(score.key)
    chromatic = sum(1 for n in vocal if n.pitch % 12 not in scale)
    first, last = min((n.onset for n in vocal), default=0), max((n.onset + n.dur for n in vocal), default=0)
    silence = 1 - sum(n.dur for n in vocal) / (last - first) if last > first else 0.0

    warn("silence", silence >= 0.25, f"{silence:.0%} of the sung span is rest (corpus ~30%)")
    if len(fills) >= 3:
        top = max(shape_counts.values()) if shape_counts else 0
        warn("answer mutation", top <= math.ceil(len(fills) / 2),
             f"{len(fills)} fills, {len(shapes)} shapes, most repeated {top}x")
    devs = plan.get("deviations") or []
    if plan:
        warn("deviations", 3 <= len(devs) <= 4, f"{len(devs)} declared (target 3-4)")
    verse_sec = "verse 1" if "verse 1" in sec_bars else ("verse" if "verse" in sec_bars else None)
    if "chorus" in sec_bars and verse_sec:
        verse = [n.pitch for n in vocal if n.section == verse_sec]
        chorus = [n.pitch for n in vocal if n.section == "chorus"]
        warn("chorus lift", not verse or not chorus or max(chorus) >= max(verse),
             f"verse max {max(verse) if verse else '-'}, chorus max {max(chorus) if chorus else '-'}")

    measured = {
        "bars": score.n_bars,
        "seconds": round(score.seconds, 1),
        "vocal_notes": len(vocal),
        "ins_notes": len(ins),
        "syllables": syllables,
        "notes_per_syllable": round(len(vocal) / syllables, 2) if syllables else None,
        "sections": sec_bars,
        "answer_rate": {k: f"{sum(v)}/{len(v)}" for k, v in answered.items()},
        "fills": len(fills),
        "shapes": len(shape_counts),
        "shape_repeats": sorted(shape_counts.values(), reverse=True),
        "register_vocal": {s: register([n for n in vocal if n.section == s]) for s in sec_bars},
        "register_mean": round(statistics.mean(vp), 1) if vp else None,
        "register_range": f"{min(vp)}-{max(vp)}" if vp else None,
        "chromatic_per_100": round(100 * chromatic / len(vocal), 2) if vocal else None,
        "simultaneities": overlap_units,
        "ties": ties,
        "ties_per_10_bars": round(10 * ties / score.n_bars, 2) if score.n_bars else None,
        "cadence_pc": last_pc,
        "final_rest": final_rest,
        "silence_share": round(silence, 2),
        "chords": score.chords,
        "deviations": len(devs),
        "top_duration_share": round(top_duration_share, 2) if top_duration_share is not None else None,
        "distinct_durations": len(duration_counts),
        "ins_active_share": round(ins_active, 2),
        "fill_lengths": [len(f) for f in fills],
        "answer_lengths": answer_lengths,
    }
    return results, measured


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("score", type=Path)
    ap.add_argument("--plan", type=Path, default=None)
    ap.add_argument("--json", type=Path, default=None)
    args = ap.parse_args(argv)

    try:
        text = args.score.read_text(encoding="utf-8")
        runtime_abc.parse_abc(text)
    except runtime_abc.AbcError as exc:
        print(f"FAIL  runtime parse  {exc}")
        return 1
    except OSError as exc:
        print(f"FAIL  parse  {exc}")
        return 1

    try:
        score = parse(text)
        finish(score)
    except (AbcError, OSError) as exc:
        print(f"FAIL  parse  {exc}")
        return 1

    plan_present = args.plan is not None
    plan = json.loads(args.plan.read_text(encoding="utf-8")) if plan_present else {}
    results, measured = check(score, plan, plan_present=plan_present)
    width = max(len(name) for _, name, _, _ in results)
    failed = 0
    for tag, name, _, detail in results:
        print(f"{tag:<4}  {name:<{width}}  {detail}")
        failed += tag == "FAIL"

    print("\nMEASURED")
    for key, value in measured.items():
        if isinstance(value, dict):
            value = " | ".join(f"{k} {v}" for k, v in value.items())
        print(f"  {key:<18} {value}")

    if args.json:
        args.json.write_text(json.dumps(
            {"ok": failed == 0,
             "checks": [{"tag": t, "name": n, "ok": o, "detail": d} for t, n, o, d in results],
             "measured": measured}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(f"\nwrote {args.json}")
    print(f"\n{'PASS' if failed == 0 else 'FAIL'}  {failed} hard check(s) failed")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
