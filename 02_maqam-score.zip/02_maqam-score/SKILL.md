---
name: maqam-score
description: >-
  Compose a NEW ABC score from Arabic lyrics and an arabmaqamrock style prompt:
  a small, declared set of deviations from the LoRA's own default arrangement.
  Ships its own syllabifier and checker, so it runs offline in two commands.
  Use when asked to write, compose, generate or design a score, melody, or ABC
  file from lyrics and a style. Do NOT use for editing an existing SheetSage2
  transcription — that is `maqam-edit`.
---

# maqam-score — composing a score from scratch

You are writing a **complete two-voice score** for a LoRA that already knows this
genre and performs competently on its own. The score is not a sketch and not a
list of gestures: it is the full vocal line plus the guitar part, bar by bar.
**Then** you declare three or four deliberate deviations from what the LoRA would
do without it. The deviations are the only intentional changes; the arrangement
around them is still a real arrangement.

The tools are bundled. You do not write a parser, a builder, a renderer, or a
syllabifier, and you do not install anything. **Run the scripts; do not read
them.** This file and `references/reference.md` are the interface.

```
<skill>/scripts/syllabify.py   lyrics -> numbers (letters, syllables, bars)
<skill>/scripts/checker.py     score + plan -> PASS/FAIL + the measured block
<skill>/scripts/abc_tools.py   vendored runtime parser (the renderer's contract)
<skill>/scripts/selftest.sh    proves both work on example/ (run once if in doubt)
<skill>/example/               a passing 16-bar score with the shape to copy
```

`<skill>` is the directory holding this file. Run the scripts by absolute path;
write `plan.json`, `score.abc` and the reports in your working directory.

## 1. The gate

You need four things:

1. **Lyrics, vocalised** — the harakat carry the count. Stripped lyrics cannot be
   counted; stop and say so.
2. **The style block** for this run.
3. **The maqam** (and the key you will write in).
4. **The lyrics file path**, for the duration cap.

If one is missing, stop and name it. Do not reconstruct it and do not guess a
key, a tempo or a maqam.

**Mode.** You are in **offline mode** unless you can actually run the renderer
(`generate.py` with the LoRA on a GPU) and listen to the result. Offline means:
priors from `references/reference.md`, no baseline render, no listening claim, no installing
`abcmidi`/`abcm2ps`, no rendering PNGs, no web search. Say "offline" in the
report. Never claim an audition that did not happen.

## 2. The baseline you deviate from

| Default behaviour | Why |
|---|---|
| answers every sung line | fixed answer rate |
| reuses one answer shape | no mutation |
| keeps density flat | no curve |
| keeps the second voice present throughout | no priority |
| builds by adding layers | conventional build |

This table is a **hypothesis** until a bare render is measured. Offline, it is
still the prior you design against — but write "prior, unmeasured" in the report.
`references/reference.md` §7 holds the measured cases; they show what good takes did, not
what the default is.

### 2.1 What a complete score contains

The measured takes are the shape gate. If the score is far outside these ranges,
it is a sketch, not a score — even if every bar adds up.

| Property | Measured takes | What it means |
|---|---|---|
| vocal mean MIDI | **73.5–75.4** | the voice sits around D5, not D4 |
| vocal top | **85–88** | the chorus reaches the top of the take |
| notes per syllable | **1.0–1.37** | 1.26 is the p02 take; 1.0 is the floor |
| most common duration | **51–57%** of notes | sixteenths/eighths mixed; not 90% one value |
| distinct durations | **5–9** | long notes, ties, and short cells all appear |
| ties per 10 bars | **0.6–1.8** | long phrase-end notes are normal |
| Ins active bars | **17–41%** | the guitar is a part, not a metronome tick |
| answer length | **3–8 notes** | a two-note tag is a stab, not an answer |
| chord symbols | **1.0–1.4 per bar** | the measured scores carry a harmony line |
| final rest | **1 full bar** after the cadence | the score ends in silence, not on a note |

These are corpus ranges, not targets to hit exactly. A declared deviation may
leave one range; it may not leave all of them. The checker measures the same
properties and fails when the plan's targets are not met.

Who owns what — do not fight another row:

| Layer | Owns |
|---|---|
| Prompt | idiom, genre, mood, production words |
| LoRA | mix, timbre, arrangement, harmonies, choir, performance |
| Score | structure, prosody, gaps, density, register, repetition |
| Listener | whether it is beautiful |

Density is yours; balance is not. Never write a busy part to "fix" the mix — the
score can only avoid causing the problem.

## 3. The pipeline — one pass

### 3.1 Numbers

```bash
python3 <skill>/scripts/syllabify.py <lyrics> --tempo <Q> --json prosody.json
```

It prints letters, syllables (marks), the duration cap and token cap, the bar
budget, the section table, and syllables per line. Copy those numbers; do not
recount by hand. If it exits 1, the lyrics need more bars than the duration
allows — raise the tempo or cut lines, do not compress the syllables. Pass
`--duration` when a render length is known, or `--bars` when the length is
already decided; otherwise the bar count comes from the prior in `references/reference.md`
§2.

### 3.2 Plan — one JSON file

Write `plan.json`. This is the brief; every value is a number or a name. The
checker fails a plan that omits a required target, so write the complete object
before the first bar.

```json
{
  "key": "Dm", "tempo": 73, "meter": "4/4", "unit": "1/16",
  "bars": 74,
  "syllables": 361,
  "sections": ["intro", "verse 1", "chorus", "verse 2", "chorus", "outro"],
  "simultaneity_exception": null,
  "melisma_min": 1.12,
  "melisma_max": 1.30,
  "register": {"mean": 74, "top": 85, "tolerance": 4},
  "max_top_duration_share": 0.75,
  "min_distinct_durations": 4,
  "ties_min": 5,
  "min_fill_notes": 3,
  "ins_active_share_min": 0.30,
  "chords_min": 37,
  "deviations": [
    {"bars": "9-32", "channel": "gap rate", "before": "an answer after every line", "after": "answers thin from 5/6 to 1/2, then stop"},
    {"bars": "33-44", "channel": "density", "before": "guitar present throughout", "after": "Ins rests through the first chorus"},
    {"bars": "45-60", "channel": "section register", "before": "verse level", "after": "verse 2 drops a fourth and stays there"},
    {"bars": "61-74", "channel": "repetition rate", "before": "the hook returns", "after": "voice stops; the guitar closes alone"}
  ]
}
```

- `sections` in order, with repeats, named exactly like the `%` markers. Take the
  names from the `SECTIONS` table `syllabify.py` printed (it reads the `[tags]`);
  do not invent a section that is not in the lyrics, and do not drop one.
- `deviations`: **3–4**, from the high-bandwidth channels only (`references/reference.md`
  §6). Position by bar. "At the chorus" is not a position. Keep `before`/`after`
  qualitative unless the number is already in `MEASURED`; a plan that claims
  "3/10" while the checker measures "4/4" is a false brief.
- `simultaneity_exception`: `null`, or one bar number you spend deliberately
  (≤ 4 sixteenths, one short note). Spend it or leave it; do not drift into it.
- `melisma_min` / `melisma_max`: notes per syllable floor and ceiling. **1.0 is
  the floor, not the target.** The measured take is 1.26; use 1.10–1.15 as the
  floor for a melismatic style, 1.0 only for a deliberately syllabic one. Ties
  do not count as extra notes.
- `register`: the verse mean and the highest note the take should reach, from
  §2.1 or a bare render. `tolerance` is how far the mean may drift.
- `max_top_duration_share`: no single duration may dominate. The measured takes
  sit at 0.51–0.57; 0.75 is the ceiling.
- `min_distinct_durations`: at least four values from
  `1,2,3,4,6,8,12,16,24,32,48` in the vocal.
- `ties_min`: tied vocal notes. Use 0 only if the style is strictly syllabic;
  otherwise a full take has 4–13.
- `min_fill_notes`: the shortest guitar answer. A two-note tag is not an answer;
  use 3, and aim for 4–8.
- `ins_active_share_min`: the share of bars where the Ins sounds. The measured
  takes are 0.17–0.41; 0.30 is a reasonable floor for a 70–90 bar score.
- `chords_min`: chord symbols. The measured takes carry 1.0–1.4 per bar; declare
  0 only when you deliberately leave harmony to the LoRA and say why.

Two or three answer shapes, each mutating; a rate that rises, falls, and partly
returns; the guitar owns the intro/interlude/outro outright. That plan lives in
the bars, not in prose.

### 3.3 Material — six decisions, before a pitch

- **Maqam and cadence figure.** The phrase that says "this maqam", used once or
  twice, entered and left by step.
- **Two or three motifs.** The vocal's cells, 3–6 notes each; every phrase
  derives from one. Write each with the transformation you will use.
- **Register.** From a bare render; offline, the `references/reference.md` §7 prior,
  labelled unmeasured. The measured verse mean is 73–76 MIDI and the top is
  85–88. Put the chorus inside the same ceiling and do not write the verse an
  octave below it.
- **Cadence note.** The tonic at each phrase end; the final vocal note is the
  tonic (the checker enforces only the last one).
- **Rhythm profile.** A sung phrase is not a row of eighth notes. Mix sixteenths
  and eighths, repeat a note, hold a long note at the phrase end, and tie it
  when it crosses a beat. Every phrase needs one gesture from the rhythm list:
  a repeated cell, a long note, a tie, or a short rest inside the phrase.
  If you can sing it as "one, two, three, four" in every bar, it is a scale,
  not a melody.
- **Answer shapes.** Two or three, 3–8 notes each, each a transformation of the
  last. The guitar owns the intro/interlude/outro outright; in the chorus it may
  become a low bed instead of an answer. A two-note tag at the barline is not
  an answer.

The checker cannot see motifs, so do not claim it did. If a motif carries an
answer shape, name that shape in the deviation list.

### 3.4 Write `score.abc`

Write the ABC directly. Do not generate it with a script and do not build one.

The dialect is fixed by the runtime parser (`abc_tools.py`). Header, exactly:

```abc
X:1
T:
M:4/4
L:1/16
Q:1/4=73
V: Vocal clef=treble name="Vocal Melody" snm="Vocal"
V: Ins clef=treble name="Ins Melody" snm="Inst."
K:Dm
% intro
V: Vocal
Z4|
V: Ins
z8 D2 E2 F2 E2|D8-D4 z4|z4 G2 F2 E2 D2 z4|D2 E2 F2 G2 A4 G4|
```

Rules that save a repair pass:

- **No blank lines anywhere in the body.** The runtime parser treats a blank
  line as the end of the tune. The checker runs the vendored parser before it
  measures anything; a blank line is a hard FAIL, not a warning.
- `% section` goes **before** the `V: Vocal` block, with a space after the
  percent (`% intro`). A `%` inside a block is an annotation and is ignored.
- Blocks alternate `V: Vocal`, `V: Ins`, each 1–4 bars, music line ending in `|`.
  Both blocks in a pair have the same bar count. Do not insert blank lines
  between pairs.
- **End with silence.** The final bar must be a full-bar rest in both voices
  (`Z|`), after the final tonic cadence. The last music line still ends with a
  plain `|`. Do **not** use `]`: the runtime parser rejects it. The final rest
  is the only clean place for the renderer/cap to stop.
- Durations are only `1,2,3,4,6,8,12,16,24,32,48` L-units. A 10-sixteenth rest
  is `z8z2`, not `z10`; a 5-sixteenth note is `3-2` tied, not `5`. No dots.
- Every bar sums to 16 at L:1/16 in 4/4. Count rests, not just notes.
- `Z` / `Z2`–`Z4` are whole-bar rests and must be the **whole** bar; `z16` is a
  rest inside one bar. Do not mix `Z` with notes in the same bar.
- Chord symbols (`"Dm"`) only in Vocal, and declare `chords_min` in the plan.
- **No `w:` lines.** The score carries no lyrics; the renderer takes them
  separately. No tuplets, no `[...]` chords, no microtonal `^/2`.
- A tie must join the same pitch and stay inside one syllable — in practice, the
  long note at a line end. Every tie is one written note.

### 3.5 Check

```bash
python3 <skill>/scripts/checker.py score.abc --plan plan.json --json report.json
```

Exit 0 is the contract. The checker runs the vendored runtime parser first; if
it prints `FAIL runtime parse`, the renderer cannot read the file at all — fix
the dialect (usually a blank line, a header line, or a tie), not the checker.
On a metric FAIL, fix **only** the bars named, then run it once more. No other
edits. If a quality target fails, write the missing music; do not lower the
target to make the score pass. If a check can only be satisfied by changing the
plan, change the plan and say so; never fake a number.

## 4. What the checks mean

**Hard — the file is unusable or the brief is empty:**

- `runtime parse`: the vendored `abc_tools.parse` accepts the file. A blank
  line, a wrong header, a mixed `Z` bar, or a bad tie fails here.
- exact dialect and headers, one meter and key, complete bars, both voices with
  equal length, declared sections and bar count;
- zero simultaneity (or the one declared bar);
- notes per syllable within `melisma_min`–`melisma_max` (the floor is a gate);
- cadence on the tonic;
- **final rest**: the last bar is a full-bar rest in both `Vocal` and `Ins`;
- a complete plan: every target key present.

**Hard when the plan declares the target** (these catch a skeleton that still
adds up):

- register mean within `tolerance` of `register.mean`;
- vocal top at least `register.top`;
- no duration is more than `max_top_duration_share` of the vocal notes;
- at least `min_distinct_durations` different vocal durations;
- at least `ties_min` tied vocal notes;
- every guitar answer is at least `min_fill_notes` notes;
- the Ins sounds in at least `ins_active_share_min` of the bars;
- at least `chords_min` chord symbols.

**Warnings (read them, they do not fail):**

- silence share — the corpus is ~24–33% rest across the sung span;
- answer mutation — if one shape answers most fills, vary it or cut the fills;
- chorus lift — the chorus should reach at least the verse's highest note;
- deviations — three or four declared, not five, not one.

**Listening is the only aesthetic gate, and it needs audio.** The numeric gates
above are about whether this is a score at all; they are not a verdict on
beauty. Offline, say so.

## 5. Report

`CHANGES.txt` = the plan's deviation list plus the checker's `MEASURED` block,
copied verbatim. `report.json` is the `--json` output. Never retype a number.
The measured block now includes `register_mean`, `register_range`,
`top_duration_share`, `distinct_durations`, `ties`, `fill_lengths`,
`ins_active_share`, and `chords`; quote them, do not restate them from memory.

If a measured value leaves the reference range, write the reason in the file.
A silent overrun is a defect; a declared one is a decision.

## 6. Traps

- Building a parser, a syllabifier, or a renderer. They are in `scripts/`.
- Installing an ABC toolchain or rendering sheet images to "look" at the score.
- Writing before the plan, then rationalising the bars against it.
- **Writing a skeleton that passes the counts.** One note per syllable, the
  guitar on whole-bar rests, two-note answers, no ties, no chords: every bar can
  add up and the result is not a score. The quality gates exist for this.
- **Copying the example as a template.** It is a 16-bar shape, not a melody.
  Copy the shape (intro/verse/chorus/outro, answers in the rests, a tied
  cadence), never the pitches.
- **Writing a scale.** `D2 F2 G2 A2 B2 A2 G2 F2` in every bar is a finger
  exercise. Start from a 3–6 note motif, repeat notes, hold a long note, and
  mutate the cell.
- **A blank line in the body.** The runtime parser ends the tune there; the
  renderer never sees the rest.
- **Ending on a note with no final rest.** The cap then has no clean place to
  cut, and the model keeps filling. Close the score with `Z|` in both voices.
- **Lowering a target to pass.** The plan is the brief. If the score misses the
  register or the fill length, write the missing music or declare the deviation
  and say why; do not edit the number.
- Deviating everywhere, or on a low-bandwidth channel (one note in a phrase) and
  waiting to hear a difference.
- A busy second voice under the vocal, then blaming the mix.
- Tying across a word boundary — the consonant lives in the transition.
- Counting bars or notes by hand and reporting the hand count.
- Claiming a listening result that was never heard.

## 7. Cost

One `syllabify` run, one plan, one score, one check, at most one repair. If you
are past that, the plan was wrong — go back to 3.2, not to the parser.
