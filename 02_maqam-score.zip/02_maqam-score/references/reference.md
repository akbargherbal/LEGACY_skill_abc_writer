# reference — numbers and the dialect

Every number is **derived** (re-run the formula) or **measured** (one dated
case). Nothing is a convention. A measured number on one case is not a rule.

## 1. Duration cap (derived)

Source: `arabmaqamrock/duration_cap.py`.

```text
N        = Arabic letters (Unicode Lo, U+0600–U+06FF); harakat are Mn, not counted
duration = 111.1 + 0.3126 × N        q = 0.95   (94.8% coverage)
duration = 122.9 + 0.3081 × N        q = 0.975
duration = 105.1 + 0.3059 × N        q = 0.90
round to the nearest 10 s, then tokens = duration × 25
```

This is an **upper bound**, not a target. The Imru' al-Qais set: N = 608 →
301.2 s → 300 s → 7500 tokens. The render that shipped was 262.15 s.

Do not use the old centre fit `92.0 + 0.280 × N`; it under-provisions.

## 2. Bars from tempo (derived, one measured prior)

At M:4/4, L:1/16, one bar = four beats.

```text
seconds_per_bar = 240 / Q
bars            = round(duration_s × Q / 240)
```

The cap over-states sung time. On the one measured case the render was
`262.15 / 301.2 = 0.87 × cap`, so the score was 80 bars at Q = 73 (not 92).
That ratio is a **prior from one case**, which is what `syllabify.py` uses when
no `--duration` is given. When a render length exists, pass it; when the plan
already fixed the bars, pass `--bars`. The checker only enforces that the score
has the bars the plan claims.

## 3. Prosody (derived per lyric, verified)

One syllable = one **vowel mark** (fatha, damma, kasra, tanwin, dagger alif).
A long vowel extends the nucleus; shadda is gemination, not a syllable. That is
the same convention as `check_abc.py:lyric_stats`, and it is why the count comes
from the tashkeel and not the letters.

The Imru' al-Qais set: 28 lines, 145 words, 608 letters, 389 marks, 14 per line.
Two bars per line is 32 sixteenths, `32 / 14 = 2.29` sixteenths per syllable —
a dotted eighth per syllable at Q = 73. Longer lines get a third bar rather than
being compressed (`syllabify.py` prints this).

A line off by one is a variant. **Do not scan the poem, look up a bahr, or
transliterate.** The job is a bar budget, not a recitation.

## 4. The ABC dialect (the parser contract)

The runtime parser is `plumbing/yue2_instrumental/abc_tools.py`. It fails closed,
and so does `checker.py`. `example/score.abc` is a passing 16-bar file; copy its
shape.

Header — exactly eight lines, no extras:

```abc
X:1
T:
M:4/4
L:1/16
Q:1/4=73
V: Vocal clef=treble name="Vocal Melody" snm="Vocal"
V: Ins clef=treble name="Ins Melody" snm="Inst."
K:Dm
```

Body: `% section`, then `V: Vocal` + 1–4 bars, then `V: Ins` + the same number
of bars. Repeat.

**A blank line ends the tune** for the runtime parser. Never put a blank line in
the body; `checker.py` runs the vendored `abc_tools.parse` first and rejects it
with `runtime parse`. Section comments are `% ` (percent + a space); `%%` is an
ABC directive, not a section marker. `Z`/`Z2`–`Z4` must be the whole bar.

**End with a full-bar rest in both voices** after the final tonic cadence
(`Z|`). Every music line still ends with a plain `|`; **`]` is not part of this
dialect** and fails the runtime parser. The checker enforces the final rest as a
hard check, and the renderer/cap then has a clean place to stop.

| token | meaning | note |
|---|---|---|
| `D4`, `d2`, `C,6` | pitch + L-units | case and `,`/`'` set the octave |
| `^F`, `_B`, `=C` | accidental | overrides the key for that letter to the bar end |
| `z16`, `z8z2` | rest | a rest of 10 is `z8z2` |
| `Z`, `Z2`–`Z4` | whole-bar rest(s) | `Z3` = three bars |
| `"Dm"` | chord symbol | Vocal only; declared in the plan or omitted |
| `d8-d8` | tie | same pitch; merges into one written note |

Legal durations: `1,2,3,4,6,8,12,16,24,32,48` L-units. No dots, no tuplets, no
`[chords]`, no grace notes, no `w:` (lyrics live outside the score). A 5-unit
note is `3-2` tied.

Bar arithmetic matters more than anything else: at L:1/16, 4/4, **every bar is
16** including its rests. A bar that sums to 15 is a failed parse, not a nuance.

## 5. Melodic material (measured corpus)

Source: `arabmaqamrock/skills/maqam-edit/SKILL.md`, 177 tracks.

- Diatonic: **0.83** accidentals per 100 notes; median track **0.38**; **74 of
  177** tracks have none; **0 of 177** are Hijaz-shaped even where the prompt
  said Hijaz.
- Consequence: spend colour at cadences, not decoratively. The checker reports
  chromatic notes per 100; the reference case is 0.0.

## 6. Bandwidth — which deviations are audible

| Channel | Bandwidth | Example |
|---|---|---|
| Silence / gap placement | highest | a line left unanswered |
| Density | high | answers pulled for two lines |
| Section register | high | chorus lifted, outro dropped |
| Repetition rate | high | the hook returns a fourth time, or not |
| Phrase shape mutation | medium | one note of the answer changes |
| Single note inside a phrase | lowest | 21 of 490 — inaudible |

Put every declared deviation in the top four rows.

## 7. The measured takes — shape targets

Five SheetSage2 transcripts of the same lyric set, different takes. These are
observations, not a rule; a declared deviation may leave one row, not all of
them.

| Take | bars | s | vocal mean | top | notes/syll | top dur share | distinct dur | ties | Ins active | Ins notes | chords |
|---|---|---|---|---|---|---|---|---|---|---|---|
| p01 | 71 | 224.6 | 73.5 | 85 | 1.28 | 51% | 7 | 13 | 35% | 123 | 85 |
| p02 | 80 | 263.0 | 75.1 | 88 | 1.26 | 56% | 9 | 8 | 39% | 215 | 99 |
| p03 | 88 | 249.5 | 74.5 | 86 | 1.17 | 54% | 6 | 10 | 41% | 276 | 116 |
| p04 | 101 | 256.0 | 75.4 | 88 | 1.26 | 57% | 7 | 6 | 36% | 250 | 138 |
| p05 | 193 | 312.3 | 74.6 | 86 | 1.37 | 55% | 8 | 12 | 17% | 301 | 198 |

What the rows say together:

- The vocal mean is **73.5–75.4**; a score whose mean is 64 is an octave below
  the corpus, whatever the bar count says.
- The top is **85–88**; `register.top` should be near it for this style.
- The most common duration is **51–57%** of the notes. A score that is 92% one
  duration is a different animal.
- Ties are **6–13** per take. A long note at a phrase end is normal.
- The guitar sounds in **17–41%** of bars and answers in phrases, not tags.
- Chords are **85–198** per take, about 1.0–1.4 per bar.

p05 is the high-melisma outlier (1.37). If you are aiming for that density,
declare `melisma_max` at least 1.40; the default 1.30 is the p02/p04 level.

## 7.1 The p02 take in detail

`p02_nahawand_a015_c15_ar075_7949497`, SheetSage2 transcript of a
YuE2/arabmaqamrock render, Q = 73, 80 bars (263 s nominal; the audio was
262.15 s), two voices.

| Property | Measured |
|---|---|
| bars with guitar | 31 |
| of those, singer silent (intro / interlude / outro) | 15 |
| of those, singer singing — guitar in the gaps | 16 |
| moments with both voices sounding | **0** |
| answer rate, verse 1 | 5 of 6 lines |
| answer rate, verse 2 | 2 of 8 lines |
| answer rate, verse 3 | 3 of 4 lines |
| answer rate, chorus 1 / 2 | 2 of 2 / 1 of 2 |
| distinct answer shapes in the verse | 3 |
| repeats per shape | 2 each |

Shape mutation, as transcribed:

```text
cdABAAG  →  cdABzAG  →  cdABAAz2  →  cdcBzAz2
DEFAdef  →  FADefed
```

Answer register per fill, ABC spelling: F4–B4, then G4–D5, then D4–F5 — it
widens and rises before it is pulled. In the chorus the guitar changes texture
instead: long low notes (`AGFE`) under the high voice — a bed, not an answer.

Gap arithmetic: the vocal's largest contiguous rest in an answered bar is 6–8
sixteenths; the answer fits inside it and leaves the bar at 16.

**These are that case's numbers, not targets.** Re-measure on your own render.

## 8. Register (procedure, not numbers)

1. Render the same lyrics bare at the same settings.
2. Transcribe the vocal, or read the MIDI range.
3. Use that range for the verse; put the chorus inside the same ceiling.

The reference case's chorus top equalled the highest note the singer reached
anywhere else: a lift *within* the voice, not beyond it. Offline, use §7 as a
prior and say the range is unmeasured.

## 9. What the score cannot express

Do not attempt these in ABC; they belong to the prompt and the LoRA:

- microtonal / quarter-tone ornament
- timbre, EQ, compression, reverb, stereo image
- consonant crispness, vocal-forward balance
- choir, backing harmonies, layered guitars, drums
- breath, belting onset, tarab inflection

Write the *place* for the ornament; the renderer performs it.
