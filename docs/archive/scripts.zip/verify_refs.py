#!/usr/bin/env python3
"""verify_refs.py - checks the file:line citations used in constraints_inventory.md.

Part 1: ANCHORS - for each cited number/constant, confirms the expected text really
        sits on the cited line(s) of the skill files.
Part 2: COVERAGE - scans the inventory markdown for every `file:line` citation and
        reports which ones are NOT backed by an anchor (those were read by eye only).

usage: python3 verify_refs.py --skill 02_maqam-score.zip [--inventory ../constraints_inventory.md]
"""
import argparse, re
from pathlib import Path
from _skill import skill_dir

S, R, C, Y, A = "SKILL.md", "references/reference.md", "scripts/checker.py", "scripts/syllabify.py", "scripts/abc_tools.py"

# (file, first_line, last_line, text that must appear on one of those lines)
ANCHORS = [
 # --- SKILL.md
 (S,77,77,"73.5–75.4"),(S,79,79,"1.0–1.37"),(S,80,80,"51–57%"),(S,81,81,"5–9"),(S,82,82,"0.6–1.8"),
 (S,83,83,"17–41%"),(S,84,84,"3–8 notes"),(S,85,85,"1.0–1.4 per bar"),(S,86,86,"final rest"),
 (S,129,129,'"bars": 74'),(S,130,130,'"syllables": 361'),(S,133,133,'"melisma_min": 1.12'),(S,134,134,'"melisma_max": 1.30'),
 (S,135,135,'"register"'),(S,136,136,'"max_top_duration_share": 0.75'),(S,137,137,'"min_distinct_durations": 4'),
 (S,138,138,'"ties_min": 5'),(S,139,139,'"min_fill_notes": 3'),(S,140,140,'"ins_active_share_min": 0.30'),
 (S,141,141,'"chords_min": 37'),(S,145,145,"verse 2 drops a fourth"),
 (S,154,154,"3–4"),(S,158,158,"simultaneity_exception"),(S,159,159,"4 sixteenths"),
 (S,160,160,"melisma_min"),(S,161,161,"1.26"),(S,161,161,"1.10–1.15"),(S,166,166,"max_top_duration_share"),(S,167,167,"0.75"),
 (S,168,168,"min_distinct_durations"),(S,170,170,"ties_min"),(S,171,171,"4–13"),(S,172,172,"min_fill_notes"),
 (S,174,174,"ins_active_share_min"),(S,175,175,"0.17–0.41"),(S,176,176,"chords_min"),(S,176,176,"1.0–1.4 per bar"),
 (S,187,187,"3–6 notes"),(S,195,195,"Rhythm profile"),(S,197,197,"Every phrase needs one gesture"),(S,198,198,"a long note"),
 (S,201,201,"3–8 notes"),(S,219,219,"L:1/16"),(S,220,220,"Q:1/4=73"),(S,238,238,"1–4 bars"),(S,241,241,"End with silence"),
 (S,245,245,"1,2,3,4,6,8,12,16,24,32,48"),(S,247,247,"sums to 16"),(S,298,298,"24–33%"),(S,348,348,"One `syllabify` run"),
 # --- reference.md
 (R,8,8,"duration_cap.py"),(R,12,12,"111.1 + 0.3126"),(R,13,13,"122.9 + 0.3081"),(R,14,14,"105.1 + 0.3059"),(R,15,15,"25"),
 (R,18,19,"N = 608"),(R,19,19,"262.15"),(R,29,29,"round(duration_s × Q / 240)"),(R,33,33,"262.15 / 301.2"),
 (R,41,41,"vowel mark"),(R,46,46,"14 per line"),(R,47,47,"2.29"),(R,51,51,"Do not scan the poem"),
 (R,81,81,"full-bar rest"),(R,95,95,"1,2,3,4,6,8,12,16,24,32,48"),(R,104,104,"177 tracks"),(R,106,106,"0.83"),
 (R,127,127,"Five SheetSage2"),(R,133,133,"| p01 |"),(R,137,137,"| p05 |"),(R,146,146,"Ties are **6–13**"),
 (R,150,151,"p05 is the high-melisma outlier"),(R,151,151,"1.30"),(R,155,155,"p02_nahawand"),(R,164,164,"both voices sounding"),
 # --- syllabify.py
 (Y,32,32,"VOWEL_MARKS"),(Y,35,35,"111.1, 0.3126"),(Y,36,36,"= 25"),(Y,39,39,"262.15 / 301.2"),(Y,42,42,"def arabic_letters"),
 (Y,50,50,"def syllables"),(Y,88,88,"default 73"),(Y,106,106,"73.0"),(Y,121,121,"DUR_CAP_A + DUR_CAP_B"),(Y,122,122,"round(cap / 10)"),
 (Y,123,123,"SECONDS_PER_LETTER_TOKENS"),(Y,130,130,"CASE_RATIO"),(Y,132,132,"round(duration * tempo / 240)"),
 (Y,139,139,"2.29"),(Y,139,139,"max(1,"),(Y,154,154,"instrumental < 0"),(Y,170,170,"<= 1"),(Y,177,177,"instrumental < 6"),
 # --- checker.py
 (C,42,42,"DURATIONS"),(C,131,131,"Z([2-4])"),(C,133,133,"1 <= len(out) <= 4"),(C,140,140,"< 9"),(C,142,142,'"X:1"'),
 (C,252,252,"not in DURATIONS"),(C,288,288,"offset != step"),(C,307,307,"units_per_bar / 4"),(C,314,314,"len(p) >= 2"),
 (C,339,339,'plan.get("bars")'),(C,343,343,"required"),(C,354,354,"sections"),(C,371,371,"<= 4"),
 (C,379,379,"len(vocal) / syllables"),(C,380,380,'"melisma_min", 1.0'),(C,381,381,'"melisma_max", 1.3'),
 (C,389,389,'"mean", 74'),(C,390,390,'"tolerance", 4'),(C,396,396,"register top"),(C,405,405,"duration spread"),
 (C,409,409,"duration variety"),(C,414,414,'"ties"'),(C,418,418,"cadence on tonic"),(C,427,427,"final rest"),
 (C,441,441,"nxt - start < 4"),(C,452,452,"<= 4"),(C,463,463,"answer fill length"),(C,469,469,"ins activity"),
 (C,473,473,'"chords"'),(C,477,477,"1.2 per bar"),(C,493,493,"silence >= 0.25"),(C,496,496,"math.ceil"),
 (C,500,500,"3 <= len(devs) <= 4"),(C,505,505,"chorus lift"),
 # --- abc_tools.py
 (A,24,24,"DURATIONS"),(A,158,158,"< 12"),(A,163,163,"usually L:1/32"),(A,165,165,"1024"),(A,216,216,"1 <= len(bars) <= 4"),
]
ALIAS = {"SKILL.md": S, "reference.md": R, "checker.py": C, "syllabify.py": Y, "abc_tools.py": A}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skill", required=True); ap.add_argument("--inventory")
    a = ap.parse_args()
    sk = skill_dir(a.skill)
    lines = {f: (sk / f).read_text(encoding="utf-8").splitlines() for f in {x[0] for x in ANCHORS}}
    bad = 0
    for f, lo, hi, text in ANCHORS:
        seg = "\n".join(lines[f][lo - 1:hi])
        if text not in seg:
            bad += 1
            print(f"MISMATCH {f}:{lo}{'-' + str(hi) if hi != lo else ''}  expected {text!r}")
    print(f"anchors: {len(ANCHORS) - bad}/{len(ANCHORS)} OK")

    inv = Path(a.inventory) if a.inventory else None
    if inv and inv.exists():
        cites = set()
        for m in re.finditer(r"(SKILL\.md|reference\.md|checker\.py|syllabify\.py|abc_tools\.py):([0-9][0-9,\s\-]*)", inv.read_text(encoding="utf-8")):
            for part in re.findall(r"\d+(?:-\d+)?", m.group(2)):
                lo, _, hi = part.partition("-")
                cites.add((ALIAS[m.group(1)], int(lo), int(hi or lo)))
        unbacked = sorted(c for c in cites
                          if not any(f == c[0] and lo <= c[2] and hi >= c[1] for f, lo, hi, _ in ANCHORS))
        print(f"\ninventory citations: {len(cites)}; backed by an anchor: {len(cites) - len(unbacked)}; read by eye only: {len(unbacked)}")
        for f, lo, hi in unbacked:
            print(f"  not anchored: {f}:{lo}{'-' + str(hi) if hi != lo else ''}")
    raise SystemExit(1 if bad else 0)


if __name__ == "__main__":
    main()
