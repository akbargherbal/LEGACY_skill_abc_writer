"""Shared helper: locate the maqam-score skill (dir or .zip) and import its scripts as modules."""
import importlib.util, tempfile, zipfile
from pathlib import Path


def skill_dir(arg: str) -> Path:
    p = Path(arg).expanduser()
    if p.suffix == ".zip":
        tmp = Path(tempfile.mkdtemp(prefix="maqam_skill_"))
        zipfile.ZipFile(p).extractall(tmp)
        hits = list(tmp.glob("SKILL.md")) + list(tmp.glob("*/SKILL.md"))
        if not hits:
            raise SystemExit(f"no SKILL.md inside {p}")
        return hits[0].parent
    if (p / "SKILL.md").exists():
        return p
    hits = list(p.glob("*/SKILL.md"))
    if hits:
        return hits[0].parent
    raise SystemExit(f"cannot find SKILL.md under {p}")


def load(skill: Path, name: str):
    """Import <skill>/scripts/<name>.py (the skill's own code, unmodified)."""
    path = skill / "scripts" / f"{name}.py"
    import sys
    sys.path.insert(0, str(path.parent))        # checker imports abc_tools
    spec = importlib.util.spec_from_file_location(f"skill_{name}", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod
