#!/usr/bin/env bash
# Re-runs every script that produced numbers in constraints_inventory.md.
#   ./run_all.sh path/to/02_maqam-score.zip path/to/lyrics.txt path/to/score.abc
set -euo pipefail
SKILL="${1:-../../02_maqam-score.zip}"; LYRICS="${2:-../lyrics.txt}"; SCORE="${3:-../baseline/score.abc}"
cd "$(dirname "$0")"; mkdir -p out
echo "== A. budget chain";            python3 budget.py "$LYRICS" --skill "$SKILL" --json out/budget.json | tee out/budget.txt
echo; echo "== E/G.2 corpus table";     python3 corpus_table.py --skill "$SKILL" | tee out/corpus_table.txt
echo; echo "== G.3/C8 example plan";    python3 plan_example_check.py "$LYRICS" --skill "$SKILL" | tee out/plan_example.txt
echo; echo "== line citations";         python3 verify_refs.py --skill "$SKILL" --inventory ../constraints_inventory.md | tee out/verify_refs.txt
echo; echo "== score (mid-line stretch)"; python3 measure.py "$SCORE" "$LYRICS" --table --json out/measure.json | tee out/measure.txt
