#!/usr/bin/env python3
"""plan_example_check.py - reproduces note G.3 and the chords_min arithmetic (row C8).

Pulls the example plan.json out of SKILL.md section 3.2 and compares it with what
syllabify computes for YOUR lyrics: bars, syllables, section names.

usage: python3 plan_example_check.py lyrics.txt --skill 02_maqam-score.zip [--tempo 73]
"""
import argparse, json, re
from pathlib import Path
from _skill import skill_dir, load


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("lyrics"); ap.add_argument("--skill", required=True); ap.add_argument("--tempo", type=float, default=73)
    a = ap.parse_args()
    sk = skill_dir(a.skill); sy = load(sk, "syllabify")
    md = (sk / "SKILL.md").read_text(encoding="utf-8")
    block = re.search(r"```json\n(.*?)```", md, re.S).group(1)
    plan = json.loads(block)

    text = Path(a.lyrics).read_text(encoding="utf-8")
    sections, _ = sy.parse_lyrics(text)
    named = [s["name"] for s in sections if s["lines"]]
    lines = [l for s in sections for l in s["lines"]]
    sylls = sum(sy.syllables(l) for l in lines)
    cap = sy.DUR_CAP_A + sy.DUR_CAP_B * sy.arabic_letters(text)
    bars = round(cap * sy.CASE_RATIO * a.tempo / 240)

    print("example plan in SKILL.md  vs  syllabify on your lyrics")
    for k, mine in (("bars", bars), ("syllables", sylls), ("sections", named)):
        print(f"  {k:10} plan={plan[k]!s:70} yours={mine!s}  {'MATCH' if plan[k] == mine else 'differs'}")
    cm = plan["chords_min"]
    print(f"\nchords_min {cm} / {plan['bars']} bars = {cm / plan['bars']:.2f} per bar   (SKILL.md sec.2.1 says 1.0-1.4 per bar -> {plan['bars']*1.0:.0f}-{plan['bars']*1.4:.0f})")
    ex = json.loads((sk / "example" / "plan.json").read_text(encoding="utf-8"))
    print(f"example/plan.json: chords_min {ex['chords_min']} / {ex['bars']} bars = {ex['chords_min'] / ex['bars']:.2f} per bar")
    print(f"\nother pre-filled values in the SKILL plan: melisma {plan['melisma_min']}-{plan['melisma_max']}, ties_min {plan['ties_min']}, "
          f"register {plan['register']}, deviations at bars {[d['bars'] for d in plan['deviations']]}")


if __name__ == "__main__":
    main()
