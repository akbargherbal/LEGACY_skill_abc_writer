#!/usr/bin/env python3
"""budget.py - reproduces inventory section A (the bar-budget chain) for any lyrics file.

Uses the skill's own functions/constants from syllabify.py (nothing re-implemented
except the 2.29 constant, which is read out of the source text at syllabify.py:139),
then cross-checks against the syllabify.py CLI output.

usage: python3 budget.py lyrics.txt --skill 02_maqam-score.zip [--tempo 73] [--json out.json]
"""
import argparse, json, re, statistics, subprocess, sys
from pathlib import Path
from _skill import skill_dir, load


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("lyrics"); ap.add_argument("--skill", required=True)
    ap.add_argument("--tempo", type=float, default=73.0); ap.add_argument("--json")
    a = ap.parse_args()
    sk = skill_dir(a.skill)
    sy = load(sk, "syllabify")
    src = (sk / "scripts" / "syllabify.py").read_text(encoding="utf-8")
    m = re.search(r"round\(n \* ([0-9.]+) / units_per_bar\)", src)
    pace = float(m.group(1))                                  # 2.29 (syllabify.py:139)

    text = Path(a.lyrics).read_text(encoding="utf-8")
    sections, _ = sy.parse_lyrics(text)
    lines = [l for s in sections for l in s["lines"]]
    sylls = [sy.syllables(l) for l in lines]
    letters = sy.arabic_letters(text)
    cap = sy.DUR_CAP_A + sy.DUR_CAP_B * letters
    cap10 = round(cap / 10) * 10
    tokens = int(round(cap10 * sy.SECONDS_PER_LETTER_TOKENS))
    duration = cap * sy.CASE_RATIO
    bars = round(duration * a.tempo / 240)
    bars_cap = round(cap * a.tempo / 240)
    upb = 16
    per_line = [max(1, round(n * pace / upb)) for n in sylls]
    body = sum(per_line)
    med = statistics.median(sylls)
    per_syl = [b * upb / n for b, n in zip(per_line, sylls)]
    flagged = [i + 1 for i, n in enumerate(sylls) if abs(n - med) > 1]

    out = {
        "constants": {"cap_a": sy.DUR_CAP_A, "cap_b": sy.DUR_CAP_B, "tokens_per_s": sy.SECONDS_PER_LETTER_TOKENS,
                      "case_ratio": round(sy.CASE_RATIO, 4), "sixteenths_per_syllable": pace},
        "letters": letters, "lines": len(lines), "syllables": sum(sylls), "median_syll_per_line": med,
        "cap_s": round(cap, 1), "cap_rounded_s": cap10, "token_cap": tokens,
        "duration_used_s": round(duration, 1), "bars": bars, "bars_from_cap": bars_cap,
        "body_bars": body, "free_bars": bars - body, "free_share": round((bars - body) / bars, 3),
        "bars_per_line_distinct": sorted(set(per_line)),
        "sixteenths_per_syllable_min": round(min(per_syl), 2), "sixteenths_per_syllable_max": round(max(per_syl), 2),
        "seconds_per_syllable_at_pace": round(pace * 60 / a.tempo / 4, 2),
        "flagged_lines": flagged,
    }
    print(f"{'N letters':32}{letters}")
    print(f"{'lines / syllables':32}{len(lines)} / {sum(sylls)}  (median {med}/line)")
    print(f"{'cap = a + b*N':32}{sy.DUR_CAP_A} + {sy.DUR_CAP_B}*{letters} = {cap:.1f} s -> {cap10} s -> {tokens} tokens")
    print(f"{'x CASE_RATIO':32}{sy.CASE_RATIO:.4f} -> {duration:.1f} s")
    print(f"{'bars = round(dur*Q/240)':32}{bars}  (from cap directly: {bars_cap})")
    print(f"{'body bars (pace %.2f)' % pace:32}{body}  = {len(lines)} lines x {out['bars_per_line_distinct']} bars")
    print(f"{'free bars':32}{bars - body}  ({out['free_share']:.0%} of the score)")
    print(f"{'16ths per syllable':32}{out['sixteenths_per_syllable_min']} .. {out['sixteenths_per_syllable_max']}   (plain eighth-per-syllable = 2.00)")
    print(f"{'seconds per syllable at pace':32}{out['seconds_per_syllable_at_pace']} s")
    print(f"{'lines flagged (|n-median|>1)':32}{flagged}")

    cli = subprocess.run([sys.executable, str(sk / "scripts" / "syllabify.py"), a.lyrics, "--tempo", str(a.tempo)],
                         capture_output=True, text=True).stdout
    got = {k: re.search(rf"{k}\s+(\d+)", cli) for k in ("bars", "body bars", "free bars", "syllables")}
    exp = {"bars": bars, "body bars": body, "free bars": bars - body, "syllables": sum(sylls)}
    ok = all(got[k] and int(got[k].group(1)) == v for k, v in exp.items())
    print(f"\ncross-check vs syllabify.py CLI: {'OK' if ok else 'MISMATCH'}")
    if a.json:
        Path(a.json).write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
