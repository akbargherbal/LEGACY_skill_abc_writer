#!/usr/bin/env python3
"""corpus_table.py - reproduces inventory section E and note G.2.

Parses the five-take table in reference.md section 7 and the "measured takes"
table in SKILL.md section 2.1, then checks every SKILL range against the table.
Also derives the tempo each take implies (bars*240/seconds, assuming 4/4).

usage: python3 corpus_table.py --skill 02_maqam-score.zip
"""
import argparse, re
from _skill import skill_dir

TOL = 0.06


def nums(s):
    return [float(x) for x in re.findall(r"[0-9]+(?:\.[0-9]+)?", s)]


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--skill", required=True)
    sk = skill_dir(ap.parse_args().skill)
    ref = (sk / "references" / "reference.md").read_text(encoding="utf-8").splitlines()
    skill = (sk / "SKILL.md").read_text(encoding="utf-8").splitlines()

    takes = {}
    for ln in ref:
        if re.match(r"\|\s*p0\d\s*\|", ln):
            c = [x.strip().rstrip("%") for x in ln.strip().strip("|").split("|")]
            bars, secs, mean, top, nps, tds, dist, ties, ins, insn, chords = map(float, c[1:12])
            takes[c[0]] = dict(bars=bars, s=secs, mean=mean, top=top, nps=nps, tds=tds, dist=dist,
                               ties=ties, ties10=10 * ties / bars, ins=ins, chords_bar=chords / bars,
                               q=bars * 240 / secs)
    print("TAKES (reference.md sec.7)")
    print(f"{'take':5}{'bars':>6}{'sec':>8}{'ties/10bars':>13}{'chords/bar':>12}{'implied Q':>11}")
    for k, t in takes.items():
        print(f"{k:5}{t['bars']:6.0f}{t['s']:8.1f}{t['ties10']:13.2f}{t['chords_bar']:12.2f}{t['q']:11.1f}")
    print("\nWhere reference.md states a tempo (check which takes they refer to):")
    for i, l in enumerate(ref, 1):
        if re.search(r"Q = \d+", l):
            print(f"  reference.md:{i}  {l.strip()[:78]}")
    print()

    series = {"vocal mean MIDI": "mean", "vocal top": "top", "notes per syllable": "nps",
              "most common duration": "tds", "distinct durations": "dist", "ties per 10 bars": "ties10",
              "Ins active bars": "ins", "chord symbols": "chords_bar"}
    claims = []
    for i, ln in enumerate(skill, 1):
        m = re.match(r"\|\s*(.+?)\s*\|\s*\*\*(.+?)\*\*\s*\|", ln)
        if m and 75 <= i <= 86:
            claims.append((i, m.group(1), m.group(2)))
    extra = []
    for i, ln in enumerate(skill, 1):
        m = re.search(r"a full take has (\d+)[–-](\d+)", ln)
        if m: extra.append((f"SKILL.md:{i}", "ties (per take)", f"{m.group(1)}–{m.group(2)}", "ties"))
    for i, ln in enumerate(ref, 1):
        m = re.search(r"Ties are \*\*(\d+)[–-](\d+)\*\* per take", ln)
        if m: extra.append((f"reference.md:{i}", "ties (per take)", f"{m.group(1)}–{m.group(2)}", "ties"))

    print("SKILL ranges vs the table")
    print(f"{'where':16}{'property':24}{'claim':>12}{'table':>16}  verdict")
    rows = [(f"SKILL.md:{i}", p, r, series.get(next((k for k in series if p.startswith(k)), ''), None)) for i, p, r in claims]
    for where, prop, rng, key in rows + extra:
        n = nums(rng)
        if key is None or len(n) < 2:
            print(f"{where:16}{prop[:23]:24}{rng:>12}{'-':>16}  not measurable from the table")
            continue
        vals = [t[key] for t in takes.values()]
        lo, hi = min(vals), max(vals)
        ok = abs(n[0] - lo) <= TOL and abs(n[1] - hi) <= TOL
        print(f"{where:16}{prop[:23]:24}{rng:>12}{f'{lo:.2f}-{hi:.2f}':>16}  {'OK' if ok else 'DIFFERS'}")


if __name__ == "__main__":
    main()
