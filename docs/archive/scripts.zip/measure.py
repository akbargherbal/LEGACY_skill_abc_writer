#!/usr/bin/env python3
"""measure.py - location-aware stretch metrics for a maqam-score ABC file.

Answers one question the skill's checker does not: WHERE are the long notes?
Splits the Vocal voice into phrases (one per lyric line), then separates the
cadence bar (last bar of the phrase) from everything before it ("mid-line").

usage:  python3 measure.py score.abc lyrics.txt [--tempo 73] [--json out.json] [--table]
"""
import argparse, json, re, sys
from collections import Counter

VOWEL_MARKS = "\u064e\u064f\u0650\u064b\u064c\u064d\u0670"   # same rule as syllabify.py
TOK = re.compile(r'"[^"]*"|([_^=]?[A-Ga-g][,\']*|[zZ])(\d*)(-?)')
LONG = 4  # sixteenths: 4+ = 0.8 s at Q=73, twice a normal sung syllable


def lyric_lines(path):
    out = []
    for raw in open(path, encoding="utf-8").read().splitlines():
        s = raw.strip()
        if not s or (s.startswith("[") and s.endswith("]")):
            continue
        if re.search(r"[\u0600-\u06FF]", s):
            out.append(sum(1 for c in s if c in VOWEL_MARKS))
    return out


def vocal_bars(path):
    voice, bars = None, []
    for line in open(path, encoding="utf-8").read().replace("\r", "").split("\n"):
        if line.startswith("V:") and "clef" not in line:
            voice = line[2:].strip(); continue
        if voice != "Vocal" or not line or line[0] in "%XTMLQVK":
            continue
        for b in line.split("|"):
            b = b.strip()
            if not b:
                continue
            toks = []
            for m in TOK.finditer(b):
                if m.group(1) is None:      # chord symbol
                    continue
                p, d, t = m.groups()
                if p == "Z":
                    toks.append(("Z", 16 * int(d or 1), False)); continue
                toks.append(("z" if p == "z" else "n", int(d or 1), t == "-", p))
            bars.append(toks)
    return bars


def split_phrases(bars):
    has_notes = lambda b: any(t[0] == "n" for t in b)
    phrases, cur = [], []
    for i, b in enumerate(bars):
        if not has_notes(b):
            if cur: phrases.append(cur); cur = []
            continue
        cur.append(b)
        trail = 0
        for t in reversed(b):
            if t[0] == "z": trail += t[1]
            else: break
        nxt_empty = i + 1 >= len(bars) or not has_notes(bars[i + 1])
        if trail >= 4 or nxt_empty:
            phrases.append(cur); cur = []
    if cur: phrases.append(cur)
    return phrases


def analyse(score, lyrics, tempo):
    sec16 = 60 / tempo / 4
    sylls = lyric_lines(lyrics)
    phrases = split_phrases(vocal_bars(score))
    rows, all_dur, ties = [], [], 0
    for i, ph in enumerate(phrases):
        last = len(ph) - 1
        notes = []                      # merged: [bar_idx, pitch, dur]
        mid_rest = 0
        pend = None
        for bi, bar in enumerate(ph):
            for t in bar:
                if t[0] == "z":
                    if bi < last: mid_rest += t[1]
                    continue
                if t[0] != "n": continue
                _, d, tie, p = t
                if pend is not None and pend[1] == p:     # tie continuation
                    pend[2] += d
                else:
                    pend = [bi, p, d]; notes.append(pend)
                if not tie: pend = None
                else: ties += 1
        mid = [n for n in notes if n[0] < last]
        cad = [n for n in notes if n[0] == last]
        rows.append({
            "phrase": i + 1,
            "syllables": sylls[i] if i < len(sylls) else None,
            "notes": len(notes),
            "mid_notes": len(mid),
            "mid_long": [n[2] for n in mid if n[2] >= LONG],
            "mid_rest16": mid_rest,
            "cad_notes": len(cad),
            "cad_sung16": sum(n[2] for n in cad),
            "mid_sung16": sum(n[2] for n in mid),
            "mid_long16": sum(n[2] for n in mid if n[2] >= LONG),
        })
        all_dur += [n[2] for n in notes]
    tot_syll = sum(sylls)
    tot_notes = sum(r["notes"] for r in rows)
    sung16 = sum(r["cad_sung16"] + r["mid_sung16"] for r in rows)
    top = Counter(all_dur).most_common(1)[0]
    s = {
        "phrases": len(phrases), "lyric_lines": len(sylls),
        "syllables": tot_syll, "notes": tot_notes,
        "notes_per_syllable": round(tot_notes / tot_syll, 2) if tot_syll else None,
        "mid_long_notes": sum(len(r["mid_long"]) for r in rows),
        "mid_long_ge6": sum(1 for r in rows for d in r["mid_long"] if d >= 6),
        "lines_with_mid_long": sum(1 for r in rows if r["mid_long"]),
        "mid_long_time_share": round(sum(r["mid_long16"] for r in rows) / sung16, 3),
        "cadence_time_share": round(sum(r["cad_sung16"] for r in rows) / sung16, 3),
        "cadence_sung_s_avg": round(sum(r["cad_sung16"] for r in rows) / len(rows) * sec16, 2),
        "mid_rest16_total": sum(r["mid_rest16"] for r in rows),
        "ties": ties,
        "distinct_durations": len(set(all_dur)),
        "top_duration_share": round(top[1] / len(all_dur), 2),
        "sung_seconds": round(sung16 * sec16, 1),
    }
    return s, rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("score"); ap.add_argument("lyrics")
    ap.add_argument("--tempo", type=float, default=73)
    ap.add_argument("--json"); ap.add_argument("--table", action="store_true")
    a = ap.parse_args()
    s, rows = analyse(a.score, a.lyrics, a.tempo)
    if s["phrases"] != s["lyric_lines"]:
        print(f"WARN phrases ({s['phrases']}) != lyric lines ({s['lyric_lines']}): per-line columns may be misaligned",
              file=sys.stderr)
    for k, v in s.items():
        print(f"{k:24} {v}")
    if a.table:
        print("\nP   syl notes mid  mid_long          mid_rest cad_notes")
        for r in rows:
            print(f"{r['phrase']:<3} {r['syllables']!s:>3} {r['notes']:>5} {r['mid_notes']:>3}  {str(r['mid_long']):<17} {r['mid_rest16']:>5}    {r['cad_notes']}")
    if a.json:
        json.dump({"summary": s, "phrases": rows}, open(a.json, "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
